Who this is for, and how to interpret this information.
	
	The contents of this folder contains the blueprints for all collaborative parties involved in the creation of this website/ application. (Web Devs/Designers/Content Creators/Company Stakeholders/Marketers)
		
	In it you will find...
		- a sitemap
		- a folder containing client-requested wire frames
		- a means to view the client-defined Objectives that motivate the resulting Deliverables found on each page.

What Objectives/ Requirements/ Deliverables are in the context of this project.
How to use and view each file. (General overview)
	They can view the documents offline, so long as the file is within the folder.
		Due to third party extensions...
Contact information for troubleshooting support, or questions regarding a clients project