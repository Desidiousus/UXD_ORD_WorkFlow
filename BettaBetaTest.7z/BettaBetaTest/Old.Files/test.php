<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Title of the document</title>

<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</head>

<body>
<div class="container">
<div class="row"> 
  <div class="col-sm-6 Form_Container" style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:410px;">
        <div>
          <h4 style="margin:0 !important;color:white;background-color:black !important;">Edit/ Remove Requirements:</h4>
        </div>
        <?php
        function OpenCon()
        {
        $dbhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $db = "MetaBeta";
        $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
        return $conn;
        }
            $connGlobal = OpenCon();
            
            $sql = "SELECT * FROM strategic_goals";
            $result = $connGlobal->query($sql);
            
            while($row = $result->fetch_assoc()) {
                $sql5 = "SELECT * FROM structure_deliverables WHERE StrategyID =". $row["id"];
                $result5 = $connGlobal->query($sql5);
                if ($result5 ->num_rows > 0) { 
                    if($row["ObjectiveType"] === "Business Objective"){
                        echo '                            
                        <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#8d9390" type="button" data-toggle="collapse" data-target="#Hidden2Req'. $row["id"] . '">
                        <strong>'. $row["ObjectiveTitle"].'</strong>
                        </button>
                        
                        <div class="collapse" id="Hidden2Req'. $row["id"] . '">      ';
                        $sql2 = "SELECT * FROM Scope_Requirements WHERE StrategyID = ".$row["id"];
                        $result2 = $connGlobal->query($sql2);
                        while($row2 = $result2->fetch_assoc()) {
                                    
                            echo '                     
                                <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#b0abc4;padding-left:15px;" type="button" data-toggle="collapse" data-target="#HiddenDeliverable'. $row2["id"] . '">
                                    <strong>'. $row2["RequirementTitle"]. '</strong>
                                </button>
                                
                                <div class="collapse" id="HiddenDeliverable'. $row2["id"] . '">'; 
                                
                                $sqlDel = "SELECT * FROM Structure_Deliverables WHERE RequirementID=".$row2["id"];
                                $Result1 = $connGlobal->query($sqlDel);
                                while($row3 = $Result1->fetch_assoc()) {
                                    if ($Result1 ->num_rows > 0) {
                                        echo '                           
                                    <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;padding-left:15px;" type="button" data-toggle="modal" data-target="#DeliveryEditModal'. $row3["id"] . '">
                                        <strong>'. $row3["DeliverableTitle"]. '</strong>
                                    </button>
                                    <div class="modal" id="DeliveryEditModal'. $row3["id"] . '">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                      
                                      <div class="modal-header">
                                        <h3 class="modal-title">Edit/Remove Requirement</h3>
                                      </div>
                                        
                                        <!-- Modal body -->
                                        <div class="modal-body">
                                        <label><strong>Strategic Objective:</strong><div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100px;"><h5>'.$row3["ObjectiveQuestion"] . '</h5><p><strong>'.$row3["ObjectiveTitle"] . '</strong><br>'.$row3["ObjectiveDescription"] . '</p></div>
                                        <form name="ModalDeliverable" action="Edit_Deliverable.php" method="post">
                                            <label><strong>Requirement:</strong><div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100px;"><h5>'.$row3["RequirementType"] . '</h5><p><strong>'.$row3["RequirementTitle"] . '</strong><br>'.$row3["RequirementDescription"] . '</p></div>
                                            <br><h3><strong>'.$row3['DeliverableType'].':</strong></h3>
                                            <form name="DeliverableModalForm" action="Edit_Deliverable.php" method="post">
                                                <input type="hidden" name="idDelReq" value="'.$row3["id"] . '">
                                                <label style="margin:0;font-size:16px;color:black;"><strong>Delivery Title:</strong></label><input name="DeliverableTitle" style="width:100%;" type="text" autocomplete="off" value="'. $row3["DeliverableTitle"].'">
                                                <label style="margin:0;font-size:16px;color:black;"><strong>Core Idea:</strong></label><textarea cols="63" rows="5" name="DeliverableCore" style="resize:vertical" autocomplete="off">'. $row3["DeliverableCoreIdea"].'</textarea>
                                                <label style="margin:0;font-size:16px;color:black;"><strong>Delivery Method:</strong></label><textarea cols="63" rows="5" name="DeliverableDelivery" style="resize:vertical" autocomplete="off">'. $row3["DeliverableDeliveryMethod"].'</textarea>
                                                <input style="float:right;color:white;background-color:red;" type="submit" name="actionR" value="Delete" />
                                                <input style="float:right;color:white;background-color:blue;" type="submit" name="actionR" value="Update" />
                                                
                                            </form>
                                        </div>
                                        
                                      
                                        
                                      </div>
                                    </div>
                                  </div>'; 
                                    }
                                } echo "</div>";
                        }echo "</div>";
                        
                    }
                }   
            }
            
            
                        
          ?>
               
                 

</body>

</html>