<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>nestedSortable jQuery Plugin</title>
    <meta content="Demo page of the nestedSortable jQuery Plugin" name="description">
    <meta content="Manuele J Sarfatti" name="author">
    <link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css" />
<script type='text/javascript' src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script> 
    <style type="text/css">
		.container {
  position: relative;
  margin-top: 60px;
  margin-left: 60px;
  margin-right: 60px;
  padding-bottom: 10px;
  min-height: 500px;
  background: #eee;
  box-shadow: 0px 0px 10px 2px #bbb;
}

.container h3 {
  position: absolute;
  border: 0;
  margin: 0;
  padding: 0;
  padding-top: 14px;
  height: 44px;
  width: 400px;
  text-indent: 80px;
  background: #4af;
  border-radius: 2px;
  box-shadow: 0px 0px 0px 2px #29f;
  pointer-events: none;
  margin-left: 0px;
  width: 100%;
  background: white;
  box-shadow: 0px 2px 0px 1px #9bf;
}

.route {
  position: relative;
  list-style-type: none;
  border: 0;
  margin: 0;
  padding: 0;
  top: 0px;
  margin-top: 0px;
  max-height: 100% !important;
  width: 100%;
  background: #bcf;
  border-radius: 2px;
  z-index: -1;
}

.route span {
  position: absolute;
  top: 20px;
  left: 20px;
  -ms-transform: scale(2);
  /* IE 9 */

  -webkit-transform: scale(2);
  /* Chrome, Safari, Opera */

  transform: scale(2);
  z-index: 10px;
}

.route .title {
  position: absolute;
  border: 0;
  margin: 0;
  padding: 0;
  padding-top: 14px;
  height: 44px;
  width: 400px;
  text-indent: 80px;
  background: #4af;
  border-radius: 2px;
  box-shadow: 0px 0px 0px 2px #29f;
  pointer-events: none;
}

.first-title { margin-left: 10px; }

.space {
  position: relative;
  list-style-type: none;
  border: 0;
  margin: 0;
  padding: 0;
  margin-left: 70px;
  width: 60px;
  top: 68px;
  padding-bottom: 68px;
  height: 100%;
  z-index: 1;
}

.first-space { margin-left: 10px; }
    </style>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
	<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.min.js"></script>
	<script type="text/javascript" src="jquery.mjs.nestedSortable.js"></script>
	
	<script>
		$().ready(function(){
			var ns = $('ol.sortable').nestedSortable({
				forcePlaceholderSize: true,
				handle: 'div',
				helper:	'clone',
				items: 'li',
				opacity: .6,
				placeholder: 'placeholder',
				revert: 250,
				tabSize: 25,
				tolerance: 'pointer',
				toleranceElement: '> div',
				maxLevels: 4,
				isTree: true,
				expandOnHover: 700,
				startCollapsed: false
			});
			
			$('.expandEditor').attr('title','Click to show/hide item editor');
			$('.disclose').attr('title','Click to show/hide children');
			$('.deleteMenu').attr('title', 'Click to delete item.');
		
			$('.disclose').on('click', function() {
				$(this).closest('li').toggleClass('mjs-nestedSortable-collapsed').toggleClass('mjs-nestedSortable-expanded');
				$(this).toggleClass('ui-icon-plusthick').toggleClass('ui-icon-minusthick');
			});
			
			$('.expandEditor, .itemTitle').click(function(){
				var id = $(this).attr('data-id');
				$('#menuEdit'+id).toggle();
				$(this).toggleClass('ui-icon-triangle-1-n').toggleClass('ui-icon-triangle-1-s');
			});
			
			$('.deleteMenu').click(function(){
				var id = $(this).attr('data-id');
				$('#menuItem_'+id).remove();
			});
				
			$('#serialize').click(function(){
				serialized = $('ol.sortable').nestedSortable('serialize');
				$('#serializeOutput').text(serialized+'\n\n');
			})
	
			$('#toHierarchy').click(function(e){
				hiered = $('ol.sortable').nestedSortable('toHierarchy', {startDepthCount: 0});
				hiered = dump(hiered);
				(typeof($('#toHierarchyOutput')[0].textContent) != 'undefined') ?
				$('#toHierarchyOutput')[0].textContent = hiered : $('#toHierarchyOutput')[0].innerText = hiered;
			})
	
			$('#toArray').click(function(e){
				arraied = $('ol.sortable').nestedSortable('toArray', {startDepthCount: 0});
				arraied = dump(arraied);
				(typeof($('#toArrayOutput')[0].textContent) != 'undefined') ?
				$('#toArrayOutput')[0].textContent = arraied : $('#toArrayOutput')[0].innerText = arraied;
			});
		});			
	
		function dump(arr,level) {
			var dumped_text = "";
			if(!level) level = 0;
	
			//The padding given at the beginning of the line.
			var level_padding = "";
			for(var j=0;j<level+1;j++) level_padding += "    ";
	
			if(typeof(arr) == 'object') { //Array/Hashes/Objects
				for(var item in arr) {
					var value = arr[item];
	
					if(typeof(value) == 'object') { //If it is an array,
						dumped_text += level_padding + "'" + item + "' ...\n";
						dumped_text += dump(value,level+1);
					} else {
						dumped_text += level_padding + "'" + item + "' => \"" + value + "\"\n";
					}
				}
			} else { //Strings/Chars/Numbers etc.
				dumped_text = "===>"+arr+"<===("+typeof(arr)+")";
			}
			return dumped_text;
		}
	</script>
</head>

<body>  
<div class="container">
  <h3 class="title" id="title0">jQuery Nested Sortable Plugin Demo</h3>
  <ul class="space first-space" id="space0">
    <li class="route">
      <h3 class="title" id="title1">A</h3>
      <span class="ui-icon ui-icon-arrow-4-diag"></span>
      <ul class="space" id="space1">
      </ul>
    </li>
    <li class="route">
      <h3 class="title" id="title2">B</h3>
      <span class="ui-icon ui-icon-arrow-4-diag"></span>
      <ul class="space" id="space2">
        <li class="route">
          <h3 class="title" id="title3">C</h3>
          <span class="ui-icon ui-icon-arrow-4-diag"></span>
          <ul class="space" id="space3">
          </ul>
        </li>
      </ul>
    </li>
    <li class="route">
      <h3 class="title" id="title4">D</h3>
      <span class="ui-icon ui-icon-arrow-4-diag"></span>
      <ul class="space" id="space4">
      </ul>
    </li>
    <li class="route">
      <h3 class="title">E</h3>
      <span class="ui-icon ui-icon-arrow-4-diag"></span>
      <ul class="space">
      </ul>
    </li>
    <li class="route">
      <h3 class="title">F</h3>
      <span class="ui-icon ui-icon-arrow-4-diag"></span>
      <ul class="space">
      </ul>
    </li>
    <li class="route">
      <h3 class="title">G</h3>
      <span class="ui-icon ui-icon-arrow-4-diag"></span>
      <ul class="space">
      </ul>
    </li>
    <li class="route">
      <h3 class="title">H</h3>
      <span class="ui-icon ui-icon-arrow-4-diag"></span>
      <ul class="space">
      </ul>
    </li>
  </ul>
</div>
</body>
</html>