<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>|Object|Requirements|Deliverables|</title>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style>
   #swapView{font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:20px;padding-bottom:20px;width:100%;text-decoration:underline;}
   #swapView:hover {font-size:22px;background-color:white !important;color:#003faa !important;text-align:center;padding-top:20px;padding-bottom:20px;width:100%;}
   #selecta:hover{background-color:orange;color:white;}
   #selecta{padding-left:15px;padding-right:15px;padding-bottom:6px;padding-top:6px;width:100%;text-align:left;font-size:20px;}
</style>
</head>

<body style="height:2000px;">
 <?php
                function OpenCon()
                {
                $dbhost = "localhost";
                $dbuser = "root";
                $dbpass = "";
                $db = "MetaBeta";
                $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
                return $conn;
                }
                $conn = OpenCon();
                
?>
<div class="container"style="margin-bottom:300px;">
<div class="row">
<?php
                    if(empty($_GET["activeObjective"]) & empty($_GET["activeRequirement"]) & empty($_GET["activeDeliverable"]) )
                    {
                                    echo '<a id="swapView" style="font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:14px;padding-bottom:14px;width:100%;" type="button" class="button" href="GenerateObjReqDel.php">Switch to Column View</a>';
                    }
                    if(!empty($_GET["activeRequirement"]) & empty($_GET["activeDeliverable"]) )
                        {
                                
                                    echo '<a id="swapView" style="font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:14px;padding-bottom:14px;width:100%;" type="button" class="button" href="GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$_GET["activeRequirement"].'">Switch to Column View</a>';
                                    
                        }

                    if(!empty($_GET["activeObjective"]) & empty($_GET["activeRequirement"]) )
                        {
                                
                            echo '<a id="swapView" style="font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:14px;padding-bottom:14px;width:100%;" type="button" class="button" href="GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'">Switch to Column View</a>'; 
                        }   
                    if(!empty($_GET["activeDeliverable"]))
                        {
                                
                            echo '<a id="swapView" style="font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:14px;padding-bottom:14px;width:100%;"  type="button" class="button" href="GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$_GET["activeRequirement"].'&activeDeliverable='.$_GET["activeDeliverable"].'">Switch to Column View</a>';
                        }   
                        
           
?>

</div>
    <div class="row" >
        <div class="col col-sm-4" style="border:solid 2px black;">
            <h2>Select Objective:</h2>
        </div>
        <div class="col col-sm-8" style="border:solid 2px black;">
            <h2>
            <?php
            if(!empty($_GET["activeObjective"]))
            {
            $sqlDel = "SELECT * FROM Strategic_Goals WHERE id = ".$_GET["activeObjective"];
                $Result1 = $conn->query($sqlDel);
                while($row = $Result1->fetch_assoc()) 
                    {
                        echo $row["ObjectiveTitle"];

                    }
                }
            ?></h2>
        </div>
    </div>
    
    <div class="row">
       <div class="col col-sm-4" style="border:solid 2px black;padding:0">
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100%;">
            <?php
                $sqlDel = "SELECT * FROM Strategic_Goals";
                $Result1 = $conn->query($sqlDel);
                while($row = $Result1->fetch_assoc()) 
                    {
                        echo '<div style="width:100%;"><a id="selecta" type="button"  href="http://localhost/MetaBetaTest/GenerateObjReqDel.1.php?activeObjective='. $row["id"].'">'.$row["ObjectiveTitle"].'</a></div>';

                    }
              
     ?></div>
        </div>
        <div class="col col-sm-8" style="border:solid 2px black;padding:0;min-height:150px">
        <?php
            if(!empty($_GET["activeObjective"]))
            {
            $sqlDel3 = "SELECT * FROM Strategic_Goals WHERE id = ".$_GET["activeObjective"];
            $Result3 = $conn->query($sqlDel3);
            while($row3 = $Result3->fetch_assoc()) 
                {
                    echo '<label style="font-size:18px;padding-left:18px;"><strong>'.nl2br(str_replace("  ", "&nbsp;", $row3["ObjectiveQuestion"])).'</strong></label><textarea style="width:100%;padding-left:20px;padding-right:25px;margin:0;padding-bottom:0;height:325px;">'. $row3["ObjectiveDescription"].'</textarea>';

                }   
            }
        ?>
    </div>


    
  </div>
  <div class="row">
        <div class="col col-sm-4" style="border:solid 2px black;">
            <h2>Select a Requirement:</h2>
        </div>
        <div class="col col-sm-8" style="border:solid 2px black;">
            <h2><?php
            if(!empty($_GET["activeRequirement"]))
            {
                $sqlDel = "SELECT * FROM scope_requirements WHERE id = ".$_GET["activeRequirement"];
                $Result1 = $conn->query($sqlDel);
                while($row = $Result1->fetch_assoc()) 
                    {
                        echo $row["RequirementTitle"];

                    }  
            } 
            
            ?></h2>
        </div>
    </div>

<div class="row">
       <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px">
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100%;">
            <?php
            if(!empty($_GET["activeObjective"]))
            {
            $sqlDel2 = "SELECT * FROM Scope_Requirements WHERE StrategyID = ".$_GET["activeObjective"];
            $Result2 = $conn->query($sqlDel2);
            while($row2 = $Result2->fetch_assoc()) 
                {
                    echo '<div style="width:100%;"><a id="selecta" type="button"  href="http://localhost/MetaBetaTest/GenerateObjReqDel.1.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$row2["id"].'">'.$row2["RequirementTitle"].'</a></div>';

                }
            }
              
    ?></div>
        </div>
        <div class="col col-sm-8" style="border:solid 2px black;padding:0;">
            <?php
            if(!empty($_GET["activeRequirement"]))
                {
                $sqlDel3 = "SELECT * FROM Scope_Requirements WHERE id = ".$_GET["activeRequirement"];
                $Result3 = $conn->query($sqlDel3);
                while($row3 = $Result3->fetch_assoc()) 
                    {
                        echo '<label style="font-size:18px;padding-left:18px;"><strong>'.nl2br(str_replace("  ", "&nbsp;", $row3["RequirementType"])).'</strong></label><textarea style="width:100%;padding-left:20px;padding-right:25px;margin:0;padding-bottom:0;height:325px;">'. $row3["RequirementDescription"].'</textarea>';

                    }   
                }?>
</div>

     
</div>
  <div class="row">
  <div class="col col-sm-4" style="border:solid 2px black;">
      <h2>Select a Deliverable:</h2>
  </div>
  <div class="col col-sm-8" style="border:solid 2px black;">
      <h2>
      <?php
      if(!empty($_GET["activeDeliverable"]))
            {
      $sqlDel = "SELECT * FROM Structure_Deliverables WHERE id = ".$_GET["activeDeliverable"];
          $Result1 = $conn->query($sqlDel);
          while($row = $Result1->fetch_assoc()) 
              {
                  echo $row["DeliverableTitle"];

              }
            }
        ?>
      </h2>
  </div>
</div>

<div class="row">
       <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;">
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100%;">  
            <?php
            if(!empty($_GET["activeRequirement"]))
            {
                $sqlDel = "SELECT * FROM Structure_Deliverables WHERE requirementID = ". $_GET["activeRequirement"];
                $Result1 = $conn->query($sqlDel);
                while($row3 = $Result1->fetch_assoc()) 
                    {
                        echo '<div style="width:100%;"><a id="selecta" type="button"  href="http://localhost/MetaBetaTest/GenerateObjReqDel.1.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$_GET["activeRequirement"].'&activeDeliverable='.$row3["id"].'">'.$row3["DeliverableTitle"].'</a></div>';

                    }
                }
                ?>
      </div>
        </div>
        <div class="col col-sm-8" style="border:solid 2px black;padding:0;">
        <?php
            if(!empty($_GET["activeDeliverable"]))
            {
            $sqlDel3 = "SELECT * FROM Structure_Deliverables WHERE id = ". $_GET['activeDeliverable'];
            $Result3 = $conn->query($sqlDel3);
            while($row3 = $Result3->fetch_assoc()) 
                {
                    echo '<label style="font-size:18px;padding-left:18px;"><strong>'.nl2br(str_replace("  ", "&nbsp;", $row3["DeliverableType"])).'</strong></label><br><textarea style="width:100%;padding-left:20px;padding-right:25px;margin:0;padding-bottom:0;height:325px">'. $row3["DeliverableCoreIdea"].'

'. $row3["DeliverableDeliveryMethod"].'</textarea>';

                }   
            }
            ?>
</div>

     

</div>
</div>

</body>
</html>