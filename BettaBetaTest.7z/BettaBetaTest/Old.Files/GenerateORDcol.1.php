<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>|Object|Requirements|Deliverables|</title>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style>
   #swapView{font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:20px;padding-bottom:20px;width:100%;text-decoration:underline;}
   #swapView:hover {font-size:22px;background-color:white !important;color:#003faa !important;text-align:center;padding-top:20px;padding-bottom:20px;width:100%;}
   #selecta:hover{background-color:orange;color:white;}
   #selecta{padding-left:15px;padding-right:15px;padding-bottom:6px;padding-top:6px;width:100%;text-align:left;font-size:20px;}
   .hide{display:none;}
   .Show{display:block;}
   #SwapToRow:hover{color:red !important;background-color:white !important;border:2px solid red;text-decoration:underline;}
   #SwapToCol:hover{color:red !important;background-color:white !important;border:2px solid red;text-decoration:underline;}
   .Selectors:hover{background-color:black !important;}
   .Selectors{border:solid black 2px;font-size:18px;padding-top:8px !important;padding-bottom:8px !important;font-weight:450;}
   .ObjSel1:hover{color:#a3c09a;border:solid 1px #a3c09a} 
   .ReqSel1:hover{color:#e8dd67;border:solid 1px #e8dd67} 
   .DelSel1:hover{color:#d98484;border:solid 1px #d98484} 
    a{margin:0;}
    .ObjHeader:hover{color:#a3c09a !important;border:solid 1px #a3c09a !important;background-color:black !important;}
    .ReqHeader:hover{color:#e8dd67 !important;border:solid 1px #e8dd67 !important;background-color:black !important;} 
   .DelHeader:hover{color:#d98484 !important;border:solid 1px #d98484 !important;background-color:black !important;} 
   .ObjHeader{height:100%;padding-top: 15px;padding-bottom:0;color:black !important;;text-decoration:underline;}
    .ReqHeader{height:100%;padding-top: 15px;padding-bottom:0;color:black !important;;text-decoration:underline;} 
   .DelHeader{height:100%;padding-top: 15px;padding-bottom:0;color:black !important;;text-decoration:underline;} 
   .ActiveItemObj{color:#a3c09a !important;border:solid 1px #a3c09a !important;background-color:black !important;}
   .ActiveItemReq{color:#e8dd67 !important;border:solid 1px #e8dd67 !important;background-color:black !important;}
   .ActiveItemDel{color:#d98484 !important;border:solid 1px #d98484 !important;background-color:black !important;}
   .scrollDiv{resize: vertical;border: 1px solid #222; padding: 10px;overflow-x:hidden;display: flex;padding-left:15px;width:100%;height:650px;float: left; display: inline;white-space: initial;overflow-wrap: break-word;max-width:100%;}
   .scrollDiv1{resize: vertical;border: 1px solid #222;width: 500px; padding: 10px;overflow-x:hidden;display: flex;padding-left:15px;width:100%;float: left; display: inline;white-space: initial;overflow-wrap: break-word;max-width:100%;padding-right:20px;}

</style>
</head>

<body style="height:2000px;">

<script>
function OBJHider(id)
    {
        var testarray = document.getElementsByClassName("SelectorsObj");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemObj');
        }
        var testarray = document.getElementsByClassName("SelectorsReq");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemReq');
        }
        var testarray = document.getElementsByClassName("SelectorsDel");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemDel');
        }
        

        var testarray = document.getElementsByClassName("SelectorsObj1");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemObj');
        }
        var testarray = document.getElementsByClassName("SelectorsReq1");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemReq');
        }
        var testarray = document.getElementsByClassName("SelectorsDel1");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemDel');
        }
        document.getElementById("SelObj1"+id).classList.add('ActiveItemObj');
        document.getElementById("SelObj"+id).classList.add('ActiveItemObj');

        var testarray = document.getElementsByClassName("ObjDesc");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('Show');
            testarray[i].classList.remove('hide'); 
            testarray[i].classList.add('hide');
        }
        var testarray2 = document.getElementsByClassName("ObjHeader");
        for(var i = 0; i < testarray2.length; i++)
        {
            testarray2[i].classList.remove('Show');
            testarray2[i].classList.remove('hide');
            testarray2[i].classList.add('hide');
        }
        var testarray3 = document.getElementsByClassName("ReqSel");
        for(var i = 0; i < testarray3.length; i++)
        {
            testarray3[i].classList.remove('Show');
            testarray3[i].classList.remove('hide');
            testarray3[i].classList.add('hide');
        }
        var testarray3 = document.getElementsByClassName("ReqSel"+ id);
        for(var i = 0; i < testarray3.length; i++)
        {
            testarray3[i].classList.remove('Show');
            testarray3[i].classList.remove('hide');
            testarray3[i].classList.add('Show');
        }
        var testarray = document.getElementsByClassName("ReqDesc");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('Show');
            testarray[i].classList.remove('hide'); 
            testarray[i].classList.add('hide');
        }
        var testarray2 = document.getElementsByClassName("ReqHeader");
        for(var i = 0; i < testarray2.length; i++)
        {
            testarray2[i].classList.remove('Show');
            testarray2[i].classList.remove('hide');
            testarray2[i].classList.add('hide');
        }
        var testarray3 = document.getElementsByClassName("DelSel");
        for(var i = 0; i < testarray3.length; i++)
        {
            testarray3[i].classList.remove('Show');
            testarray3[i].classList.remove('hide');
            testarray3[i].classList.add('hide');
        }
        var element =  document.getElementById("ReqSel" + id);
            if (typeof(element) != 'undefined' && element != null)
            {
            document.getElementById("ReqSel" + id).classList.add('Show');
            document.getElementById("ReqSel" + id).classList.remove('hide');
            }
            var testarray = document.getElementsByClassName("DelDesc");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('Show');
            testarray[i].classList.remove('hide'); 
            testarray[i].classList.add('hide');
        }
        var testarray2 = document.getElementsByClassName("DelHeader");
        for(var i = 0; i < testarray2.length; i++)
        {
            testarray2[i].classList.remove('Show');
            testarray2[i].classList.remove('hide');
            testarray2[i].classList.add('hide');
        }

        document.getElementById("HeaderOBJ" + id).classList.add('Show');
        document.getElementById("HeaderOBJ" + id).classList.remove('hide');
        document.getElementById("HeaderDesc" + id).classList.add('Show');
        document.getElementById("HeaderDesc" + id).classList.remove('hide');   
        document.getElementById("HeaderOBJ1" + id).classList.add('Show');
        document.getElementById("HeaderOBJ1" + id).classList.remove('hide');
        document.getElementById("HeaderDesc1" + id).classList.add('Show');
        document.getElementById("HeaderDesc1" + id).classList.remove('hide'); 

    }     
function ReqHider(id){
    var testarray = document.getElementsByClassName("ReqDesc");
    for(var i = 0; i < testarray.length; i++)
    {
        testarray[i].classList.remove('Show');
        testarray[i].classList.remove('hide'); 
        testarray[i].classList.add('hide');
    }
    var testarray2 = document.getElementsByClassName("ReqHeader");
    for(var i = 0; i < testarray2.length; i++)
    {
        testarray2[i].classList.remove('Show');
        testarray2[i].classList.remove('hide');
        testarray2[i].classList.add('hide');
    }
    var testarray3 = document.getElementsByClassName("DelSel" );
    for(var i = 0; i < testarray3.length; i++)
    {
        testarray3[i].classList.remove('Show');
        testarray3[i].classList.remove('hide');
        testarray3[i].classList.add('hide');
    }
    var testarray3 = document.getElementsByClassName("DelSel" +id);
    for(var i = 0; i < testarray3.length; i++)
    {
        testarray3[i].classList.remove('Show');
        testarray3[i].classList.remove('hide');
        testarray3[i].classList.add('Show');
    }
    var testarray = document.getElementsByClassName("DelDesc");
    for(var i = 0; i < testarray.length; i++)
    {
        testarray[i].classList.remove('Show');
        testarray[i].classList.remove('hide'); 
        testarray[i].classList.add('hide');
    }
    var testarray2 = document.getElementsByClassName("DelHeader");
    for(var i = 0; i < testarray2.length; i++)
    {
        testarray2[i].classList.remove('Show');
        testarray2[i].classList.remove('hide');
        testarray2[i].classList.add('hide');
    }
    var testarray = document.getElementsByClassName("SelectorsReq1");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemReq');
        }
    var testarray = document.getElementsByClassName("SelectorsDel1");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemDel');
        }
    var testarray = document.getElementsByClassName("SelectorsReq");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemReq');
        }
    var testarray = document.getElementsByClassName("SelectorsDel");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemDel');
        }
        document.getElementById("SelReq"+id).classList.add('ActiveItemReq');
        document.getElementById("SelReq1"+id).classList.add('ActiveItemReq');

    document.getElementById("HeaderReq" + id).classList.add('Show');
    document.getElementById("HeaderReq" + id).classList.remove('hide');
    document.getElementById("ReqDesc" + id).classList.add('Show');
    document.getElementById("ReqDesc" + id).classList.remove('hide');   
    
    document.getElementById("ReqDesc1" + id).classList.add('Show');
    document.getElementById("ReqDesc1" + id).classList.remove('hide');  
    document.getElementById("HeaderReq1" + id).classList.add('Show');
    document.getElementById("HeaderReq1" + id).classList.remove('hide');
    } 

function DelHider(id){
    var testarray = document.getElementsByClassName("DelDesc");
    for(var i = 0; i < testarray.length; i++)
    {
        testarray[i].classList.remove('Show');
        testarray[i].classList.remove('hide'); 
        testarray[i].classList.add('hide');
    }
    var testarray2 = document.getElementsByClassName("DelHeader");
    for(var i = 0; i < testarray2.length; i++)
    {
        testarray2[i].classList.remove('Show');
        testarray2[i].classList.remove('hide');
        testarray2[i].classList.add('hide');
    }
    var testarray = document.getElementsByClassName("SelectorsDel");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemDel');
        }
    document.getElementById("SelDel"+id).classList.add('ActiveItemDel');

    var testarray = document.getElementsByClassName("SelectorsDel1");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('ActiveItemDel');
        }
    document.getElementById("SelDel1"+id).classList.add('ActiveItemDel');
    
    document.getElementById("HeaderDel" + id).classList.add('Show');
    document.getElementById("HeaderDel" + id).classList.remove('hide');
    document.getElementById("DelDesc" + id).classList.add('Show');
    document.getElementById("DelDesc" + id).classList.remove('hide');   
    document.getElementById("HeaderDel1" + id).classList.add('Show');
    document.getElementById("HeaderDel1" + id).classList.remove('hide');
    document.getElementById("DelDesc1" + id).classList.add('Show');
    document.getElementById("DelDesc1" + id).classList.remove('hide');   

    }           
function ColView(){
    document.getElementById("ColView" ).classList.remove('hide');   
    document.getElementById("ColView" ).classList.remove('Show');   
    document.getElementById("ColView" ).classList.add('hide');     
    document.getElementById("RowView" ).classList.remove('hide');   
    document.getElementById("RowView" ).classList.remove('Show');   
    document.getElementById("RowView" ).classList.add('Show');  
    }       
function RowView(){
    document.getElementById("RowView" ).classList.remove('hide');   
    document.getElementById("RowView" ).classList.remove('Show');   
    document.getElementById("RowView" ).classList.add('hide');     
    document.getElementById("ColView" ).classList.remove('hide');   
    document.getElementById("ColView" ).classList.remove('Show');   
    document.getElementById("ColView" ).classList.add('Show');  
    }    
                 
</script>
 <?php
                function OpenCon()
                {
                $dbhost = "localhost";
                $dbuser = "root";
                $dbpass = "";
                $db = "MetaBeta";
                $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
                return $conn;
                }
                $conn = OpenCon();
                
?>
<div id="ColView" class="container hide"style="margin-bottom:300px;max-width:100% !important;" >
    <div class="row">   
        <div class="col col-sm-12" style="border:solid black 2px;text-align:center;color:white;background-color:blue !important;padding:0;">
                    <button style="color:white;background-color:blue;width:100%;font-size:25px;text-decoration:underline;" id="SwapToRow" type="button" onclick="ColView();">Switch to Row view</a>
    </div>                           
    </div>  
    <div class="row">
                <div class="col col-sm-4" style="border:solid black 2px;background-color:#a3c09a;width:100%;padding:0;padding-top: 22px;">
                    <h2 style="padding-left: 15px;">Select an Objective:</h2>
                </div>
                <div class="col col-sm-4" style="border:solid black 2px;background-color:#e8dd67;width:100%;padding:0;padding-top: 22px;">
                    <h2 style="padding-left: 15px;">Select a Requirement:</h2>
                </div>
                <div class="col col-sm-4" style="border:solid black 2px;background-color:#d98484;width:100%;padding:0;padding-top: 22px;">
                    <h2 style="padding-left: 15px;">Select a Deliverable:</h2>
                </div>
                
                

 

    </div>
    <div class="row" >
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;">
                    <div style="overflow:scroll;overflow-x:hidden;padding:0;min-height:250px;height:100%;background-color:#e3f8dd;">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Strategic_Goals ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ObjSel1' style='width:100%;padding:0;'><button id='SelObj".$row["id"]."' class='Selectors SelectorsObj ObjSel1' style='text-align:left;padding:0;padding-left:10px;width:100%;padding-top: 22px;' onclick=' OBJHider(".$row["id"].")'>".$row["ObjectiveTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;background-color:#fffcdc;">
                    <div style="overflow:scroll;padding:0;overflow-x:hidden;min-height:250px;height:100%;">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div id='ReqSel".$row["ObjectiveSeqID"]."' class='ReqSel ReqSel".$row["ObjectiveSeqID"]." hide' style='width:100%;padding:0;'><button id='SelReq".$row["ObjectiveSeqID"]."' class='Selectors SelectorsReq ReqSel1' style='text-align:left;padding:0;padding-left:10px;width:100%;padding-top: 22px;' onclick=' ReqHider(".$row["id"].")'>".$row["RequirementTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;background-color:#fff5f5;">
                    <div style="overflow:scroll;padding:0;overflow-x:hidden;min-height:250px;height:100%;">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div id='DelSel".$row["id"]."' class='DelSel DelSel".$row["id"]." hide' style='width:100%;padding:0;'><button id='SelDel".$row["id"]."' class='Selectors SelectorsDel DelSel1' style='text-align:left;padding:0;padding-left:10px;width:100%;' onclick=' DelHider(".$row["id"].")'>".$row["DeliverableTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                
    </div>



    <div class="row">
                <div class="col col-sm-4" style="border:solid black 2px;background-color:#a3c09a;width:100%;padding:0;">
                    <?php
                            
                            $sqlDel = "SELECT * FROM Strategic_Goals";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<a  class='ObjHeader hide' id='HeaderOBJ".$row["ObjectiveSeqID"]."' style='height:100%;padding-top: 15px;padding-bottom:15px;color:black;text-decoration:underline;' href='http://localhost/MetaBetaTest/TestList.php#Obj".$row["id"]."' onclick='window.open(\"http://localhost/MetaBetaTest/TestList.php#Obj".$row["id"]."\", \"newwindow\", \"width=1500,height=1000 \"); return false;' ><div style='padding-left: 15px;padding-right: 15px;' ><h3 style='margin: 0px !important'>".$row["ObjectiveTitle"]."</h2></div></a>";
            
                                }
                            
                    ?>
                </div>
                <div class="col col-sm-4" style="border:solid black 2px;background-color:#e8dd67;width:100%;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<a class='ReqHeader".$row["ObjectiveSeqID"]." hide' style='height:100%;padding-top: 15px;padding-bottom:15px;color:black;text-decoration:underline;' href='http://localhost/MetaBetaTest/TestList.php#Req".$row["id"]."' onclick='window.open(\"http://localhost/MetaBetaTest/TestList.php#Req".$row["id"]."\", \"newwindow\", \"width=1500,height=1000 \"); return false;' ><div style='padding-left: 15px;padding-right: 15px;' ><h3 style='margin: 0px !important'>".$row["RequirementTitle"]."</h2></div>";
            
                                }
                            
                    ?>
                </div>
                <div class="col col-sm-4" style="border:solid black 2px;background-color:#d98484;width:100%;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<a class='DelHeader".$row["RequirementID"]." hide' style='height:100%;padding-top: 15px;padding-bottom:15px;color:black;text-decoration:underline;' href='http://localhost/MetaBetaTest/TestList.php#Del".$row["id"]."' onclick='window.open(\"http://localhost/MetaBetaTest/TestList.php#Del".$row["id"]."\", \"newwindow\", \"width=1500,height=1000 \"); return false;' ><div style='padding-left: 15px;padding-right: 15px;' ><h3 style='margin: 0px !important;'>".$row["DeliverableTitle"]."</h2></div></a>";
            
                                }
                            
                    ?>
                </div>


    </div>
    <div class="row" >
    <div class="col col-sm-4" style="border:solid black 2px;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Strategic_Goals ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    str_replace(" ", "&nbsp;",str_replace("\r", "<br>", $row["ObjectiveDescription"]));
                                    echo "<div class='ObjDesc".$row["ObjectiveSeqID"]." hide' style='height:100%;padding:0;background-color:white;'><h4 style='margin-left:15px;'>". $row["ObjectiveQuestion"]."</h4><h5 style='margin-left:15px;'>". $row["ObjectiveTitle"]."</h5><div class='scrollDiv'>".nl2br(str_replace("    ", "&nbsp;&nbsp;&nbsp;&nbsp;",str_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;", $row["ObjectiveDescription"])))."</div></div>";
            
                                }
                            
                    ?>
                </div>
                <div class="col col-sm-4" style="border:solid black 2px;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ReqDesc  ReqDesc".$row["ObjectiveSeqID"]." hide' style='height:100%;padding:0;background-color:white'><h4  style='padding-left:15px;'>".nl2br(str_replace("  ", "&nbsp;", str_replace("\r", "<br>",$row["RequirementType"])))."</h4><h5  style='padding-left:15px;'>".nl2br(str_replace("  ", "&nbsp;", str_replace("\r", "<br>",$row["RequirementTitle"])))."</h5><div class='scrollDiv'>".nl2br(str_replace("    ", "&nbsp;&nbsp;&nbsp;&nbsp;",str_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;", $row["RequirementDescription"])))."</div></div>";
            
                                }
                            
                    ?>
                </div>
                <div class="col col-sm-4" style="border:solid black 2px;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='DelDesc  DelDesc".$row["RequirementID"]." hide' style='height:100%;padding:0;background-color:white;height:100%;'><h4 style='padding-left:15px;'>".$row["DeliverableType"].":</h4><h5 style='padding-left:15px;'>".$row["DeliverableTitle"].":</h5><div class='scrollDiv1'>".nl2br(str_replace("  ", "&nbsp;",str_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;", $row["DeliverableCoreIdea"])))."<br>".str_replace("  ", "&nbsp;",str_replace("\r", "<br>", $row["DeliverableDeliveryMethod"]))."</div></div>";
            
                                }
                            
                    ?>
                </div>


    </div>
</div>
    
<div id="RowView" class="container "style="margin-bottom:300px;">
    <div class="row">
    <div class="col col-sm-12" style="border:solid black 2px;text-align:center;color:white;background-color:blue !important;padding:0 !important;" >
                    <button style="color:white;background-color:blue;width:100%;font-size:25px;text-decoration:underline;" id="SwapToCol" type="button" onclick="RowView();">Switch to Column view</a>
    </div>                             
    </div>                           
    <div class="row">
                <div class="col col-sm-4" style="border:solid black 2px;padding-top:22px !important;background-color:#a3c09a">
                    <h2>Select an Objective:</h2>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;background-color:#a3c09a;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Strategic_Goals ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<a class='ObjHeader hide' id='HeaderOBJ1".$row["id"]."' style='padding-left:15px;width:100%;height:100%;padding-top:22px;' href='http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Obj".$row["id"]."' onclick='window.open(\"http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Obj".$row["id"]."\", \"newwindow\", \"width=1500,height=1000 \"); return false;' ><div style='height:100%;'><h3 style='padding-right: 15px;'>".$row["ObjectiveTitle"]."</h2></div></a>";
            
                                }
                            
                    ?>
                </div>


    </div>
    <div class="row" >
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;background-color:#e3f8dd">
                    <div style="overflow:scroll;overflow-x:hidden;padding:0;min-height:250px;height:100%;">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Strategic_Goals ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ObjSel1' style='width:100%;padding:0;'><button id='SelObj1".$row["id"]."' class='Selectors SelectorsObj1 ObjSel1' style='text-align:left;padding:0;padding-left:15px;width:100%;' onclick=' OBJHider(".$row["ObjectiveSeqID"].")'>".$row["ObjectiveTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Strategic_Goals ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ObjDesc hide' style='padding:0;background-color:white;' id='HeaderDesc1".$row["id"]."'><h3  style='padding-left:15px;'>".$row["ObjectiveQuestion"]."</h3><h5  style='padding-left:15px;'>".$row["ObjectiveTitle"]."</h5><div class='scrollDiv1'>".nl2br(str_replace("    ", "&nbsp;&nbsp;&nbsp;&nbsp;",str_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;", $row["ObjectiveDescription"])))."</div></div>";
            
                                }
                            
                    ?>
                </div>
    </div>



    <div class="row">
                <div class="col col-sm-4" style="border:solid black 2px;background-color:#e8dd67;padding-top:22px !important;">
                    <h2>Select a Requirement:</h2>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;background-color:#e8dd67;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<a style='width:100%;height:100%;padding-left:15px;padding-top:22px;' class='ReqHeader hide' id='HeaderReq1".$row["id"]."' href='http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Req".$row["id"]."' onclick='window.open(\"http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Req".$row["id"]."\", \"newwindow\", \"width=1500,height=1000 \"); return false;' ><div style='height:100%;'><h3 style='padding-right: 15px;'>".$row["RequirementTitle"]."</h2></div></a>";
            
                                }
                            
                    ?>
                </div>


    </div>
    <div class="row" >
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;background-color:#fffcdc;">
                    <div style="overflow:scroll;overflow-x:hidden;padding:0;min-height:250px;height:100%;">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div id='ReqSel".$row["StrategyID"]."' class='ReqSel ReqSel".$row["StrategyID"]." hide' style='width:100%;padding:0;'><button id='SelReq1".$row['ObjectiveSeqID']."' class='SelectorsReq1 Selectors ReqSel1' style='text-align:left;padding:0;padding-left:15px;width:100%;' onclick=' ReqHider(".$row["id"].")'>".$row["RequirementTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;padding:0;background-color:white;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ReqDesc  hide' style='padding:0;' id='ReqDesc1".$row["id"]."'><h3  style='padding-left:15px;'>".$row["RequirementType"]."</h3><h5  style='padding-left:15px;'>".$row["RequirementTitle"]."</h5><div class='scrollDiv1'>".nl2br(str_replace("    ", "&nbsp;&nbsp;&nbsp;&nbsp;",str_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;", $row["RequirementDescription"])))."</div></div>";
            
                                }
                            
                    ?>
                </div>


    </div>



    <div class="row">
                <div class="col col-sm-4" style="border:solid black 2px;background-color:#d98484;padding-top:22px !important;">
                    <h2>Select a Deliverable:</h2>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;background-color:#d98484;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<a style='width:100%;height:100%;padding-left:15px;padding-top:22px;' class='DelHeader hide' id='HeaderDel1".$row["id"]."' href='http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Del".$row["id"]."' onclick='window.open(\"http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Del".$row["id"]."\", \"newwindow\", \"width=1500,height=1000 \"); return false;' ><div style='height:100%;'><h3 style='padding-right: 15px;'>".$row["DeliverableTitle"]."</h2></div></a>";
            
                                }
                            
                    ?>
                </div>


    </div>
    <div class="row" >
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;">
                    <div style="overflow:scroll;overflow-x:hidden;padding:0;min-height:250px;height:100%;background-color:#fff5f5">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div id='DelSel".$row["RequirementID"]."' class='DelSel DelSel".$row["RequirementID"]." hide' style='width:100%;padding:0;'><button id='SelDel1".$row['id']."' class='SelectorsDel1 Selectors DelSel1' style='text-align:left;padding:0;padding-left:15px;width:100%;' onclick=' DelHider(".$row["id"].")'>".$row["DeliverableTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;padding:0;background-color:white;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='DelDesc hide' style='padding:0;' id='DelDesc1".$row["id"]."'><h3 style='padding-left:15px;'>".$row["DeliverableType"].":</h3><h5 style='padding-left:15px;'>".$row["DeliverableTitle"]."</h5><div class='scrollDiv1'>".nl2br(str_replace("  ", "&nbsp;",str_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;", $row["DeliverableCoreIdea"])))."<br>".str_replace("  ", "&nbsp;",str_replace("\r", "<br>", $row["DeliverableDeliveryMethod"]))."</div></div>";
            
                                }
                            
                    ?>
                </div>


    </div>
</div>
</body>
</html>