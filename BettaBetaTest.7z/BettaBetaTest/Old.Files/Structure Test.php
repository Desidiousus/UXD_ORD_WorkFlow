<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Title of the document</title>

<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</head>

<body>
<div class="container">
<div class="row"> 
  <div class="col-sm-6 Form_Container" style="">
        <div>
          <h4 style="margin:0 !important;color:white;background-color:black !important;">Global Navigation Tags:</h4>
        </div>
        <form name="CreateGlobalTag" action="Create Global Tag.php" method="post" >
            <label style="margin:0;font-size:16px;color:black !important;"><strong>Create a webpage to host deliverables:</strong></label><br>
                <input name="GlobalTagTitle" autocomplete="off" style="width:100%;" type="text"><br>
                <input type="submit" style="float:right;" value="Submit"><br><br>
        </form>
        
            <label style="margin:0;font-size:16px;color:black !important;"><strong>Edit/ Remove Webpages:</strong></label><br>
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;">
                <?php
                    function OpenCon()
                    {
                    $dbhost = "localhost";
                    $dbuser = "root";
                    $dbpass = "";
                    $db = "Template";
                    $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
                    return $conn;
                    }
                        $connGlobal = OpenCon();
                        
                        $sql = "SELECT * FROM structure_deliverables WHERE DeliverableGlobalNavTagList IS NOT NULL AND DeliverableType IS NULL";
                        $result = $connGlobal->query($sql);
                        while($row = $result->fetch_assoc()) {
                            echo '                           
                            <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;padding-left:30px;" type="button" data-toggle="modal" data-target="#TagEditModal'. $row["id"] . '">
                                <strong>'. $row["DeliverableGlobalNavTagList"]. '</strong>
                            </button>';
                            
                            
                                echo 
                                '<div class="modal" id="TagEditModal'. $row["id"] . '">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                
                                <div class="modal-header">
                                    <h3 class="modal-title">Edit/Remove Global Navigation Tags</h3>
                                </div>
                                    
                                    <!-- Modal body -->
                                    <div class="modal-body">
                                   

                                        <label style="margin:0;font-size:16px;color:black;"><strong>Global Nav Tag Title:</strong></label>
                                        <form name="ModalEditGlobalNavTags" action="Edit_Global_Navigation_Tag.php" method="post">
                                            <input type="hidden" name="idDelReq" value="'.$row["id"] . '">
                                            <input name="GlobalNavTagEdit" style="width:100%;" type="text" autocomplete="off" value="'. $row["DeliverableGlobalNavTagList"].'">
                                            <input style="float:right;color:white;background-color:blue;" type="submit" name="actionR" value="Update" />
                                            <input style="float:left;color:white;background-color:red;" type="submit" name="actionR" value="Delete" /></form>
                                            </form> 

                                    <br><br><br>
                                    
                                    <form style="margin-top:7px;" name="DeliverableModalForm" action="Add_Deliverable_Global.php" method="post">
                                        <input type="hidden" name="AddGlobalTag" value="'. $row["DeliverableGlobalNavTagList"]. '">
                                        <label style="margin:0;font-size:16px;color:black;"><strong>Add Selected Deliverables To Web Page Tag:</strong></label><br>
                                        <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;"><input type="hidden" name="AddGlobalTag" value="'. $row["DeliverableGlobalNavTagList"]. '">
                                        ';
//Check box Local Grouping Condition
                                            $sql5 = "SELECT * FROM structure_deliverables WHERE (DeliverableTitle IS NULL AND DeliverableLocalNavTagList IS NOT NULL AND DeliverableGlobalNavTag IS NULL) OR
                                            (DeliverableTitle IS NULL AND DeliverableLocalNavTagList IS NOT NULL AND DeliverableGlobalNavTag != '". $row["DeliverableGlobalNavTagList"]."' )";
                                            $result5 = $connGlobal->query($sql5) or die($connGlobal->error);
                                            while($row5 = $result5->fetch_assoc()) {
                                                echo '<div style="border:solid black 2px;background-color:#29A5FF">
                                                      <input type="checkbox" name="AddLocalTagToGlobal'.$row5["id"].'" value="'.$row5["id"].'"><strong>'.$row5["DeliverableLocalNavTagList"].'</strong><br>';

                                                    $sql4 = "SELECT * FROM structure_deliverables WHERE (DeliverableTitle IS NOT NULL AND DeliverableLocalNavTag ='".$row5["DeliverableLocalNavTagList"]."')" ;
                                                    $result4 = $connGlobal->query($sql4) or die($connGlobal->error);
                                                    while($row4 = $result4->fetch_assoc()) {
                                                        
                                                            echo '<div style="border-bottom:solid black 1px;padding-left:30px;background-color:#99DFFF;width:100%;">'.$row4["DeliverableTitle"].'</div>';
                                                        }
                                                echo '</div>';        
                                            }
                                            
                                        $sql2 = "SELECT * FROM structure_deliverables WHERE  (DeliverableTitle IS NOT NULL AND DeliverableLocalNavTag IS NULL AND DeliverableGlobalNavTag IS NULL ) OR (DeliverableTitle IS NOT NULL AND NOT DeliverableGlobalNavTag = '". $row["DeliverableGlobalNavTagList"]. "' AND DeliverableLocalNavTag IS NULL) ";
                                        $result3 = $connGlobal->query($sql2) or die($connGlobal->error);
                                            while($row3 = $result3->fetch_assoc()) {
                                                echo '<div style="background-color:#679e97;border:black 2px solid;"><strong><input type="checkbox" name="AddDeliverable'.$row3["id"].'" value="'.$row3["id"].'">'.$row3["DeliverableTitle"].'</strong></div>';
                                            }
                                            echo '
                                        </div>
                                        <input style="float:right;color:white;background-color:green;" type="submit" name="actionR" value="ADD" />
                                    </form> 
                                    <br>
                                    
                                    <form style="margin-top:7px;" name="RemoveModalForm" action="Remove_Deliverable_Global.php" method="post">
                                        
                                        <label style="margin:0;font-size:16px;color:black;"><strong>Remove Selected Deliverables From Web Page Tag:</strong></label><br>
                                        <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;">';
                                            
                                            $sql5 = "SELECT * FROM structure_deliverables WHERE (DeliverableTitle IS NULL AND DeliverableLocalNavTagList IS NOT NULL AND DeliverableGlobalNavTag = '". $row["DeliverableGlobalNavTagList"]."' )";
                                            $result5 = $connGlobal->query($sql5) or die($connGlobal->error);
                                            while($row5 = $result5->fetch_assoc()) {
                                                echo '<div style="border:solid black 2px;background-color:#29A5FF">
                                                      <input type="checkbox" name="AddLocalTagToGlobal'.$row5["id"].'" value="'.$row5["id"].'"><strong>'.$row5["DeliverableLocalNavTagList"].'</strong><br>';

                                                    $sql4 = "SELECT * FROM structure_deliverables WHERE (DeliverableTitle IS NOT NULL AND DeliverableLocalNavTag ='".$row5["DeliverableLocalNavTagList"]."')" ;
                                                    $result4 = $connGlobal->query($sql4) or die($connGlobal->error);
                                                    while($row4 = $result4->fetch_assoc()) {
                                                        
                                                            echo '<div style="border-bottom:solid black 1px;padding-left:30px;background-color:#99DFFF;width:100%;">'.$row4["DeliverableTitle"].'</div>';
                                                        }
                                                echo '</div>';        
                                            }
                                            $sql2 = "SELECT * FROM structure_deliverables WHERE (DeliverableGlobalNavTag='". $row["DeliverableGlobalNavTagList"]. "' AND DeliverableLocalNavTag IS NULL AND DeliverableTitle IS NOT NULL)";
                                            $result2 = $connGlobal->query($sql2) or die($connGlobal->error);
                                                while($row2 = $result2->fetch_assoc()) {
                                                    echo '<div style=background-color:#679e97;border:black 2px solid;"><input type="checkbox" name="RemoveDeliverable'.$row2["id"].'" value="'.$row2["id"].'"><strong>'.$row2["DeliverableTitle"].'</strong></div>';
                                                }    
                                            echo '
                                        </div>
                                        <input style="float:right;color:white;background-color:red;" type="submit" name="actionR" value="REMOVE" />
                                    </form> 
                                </div>
                                    
                                
                                    
                                </div>
                                </div>
                            </div>';
                        
                    }
                                    
                ?>
            </div> </div>
            <div class="col-sm-6 Form_Container" style="">
        <div>
          <h4 style="margin:0 !important;color:white;background-color:black !important;">Local Navigation Tags:</h4>
        </div>
        <form name="CreateLocalTag" action="Create Local Tag.php" method="post" >
            <label style="margin:0;font-size:16px;color:black !important;"><strong>Create a group name for deliverables:</strong></label><br>
                <input name="LocalTagTitle" autocomplete="off" style="width:100%;" type="text"><br>
                <input type="submit" style="float:right;" value="Submit"><br><br>
        </form>
        
            <label style="margin:0;font-size:16px;color:black !important;"><strong>Edit/ Remove Local Groupings:</strong></label><br>
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;">
                <?php
                    $connGlobal = OpenCon();
                        
                        $sql = "SELECT * FROM structure_deliverables WHERE DeliverableLocalNavTagList IS NOT NULL AND DeliverableType IS NULL";
                        $result = $connGlobal->query($sql);
                        while($row = $result->fetch_assoc()) {
                            echo '                           
                            <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#29A5FF;padding-left:30px;" type="button" data-toggle="modal" data-target="#TagEditModal'. $row["id"] . '">
                                <strong>'. $row["DeliverableLocalNavTagList"]. '</strong>
                            </button>';
                            
                            
                                echo 
                                '<div class="modal" id="TagEditModal'. $row["id"] . '">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                
                                <div class="modal-header">
                                    <h3 class="modal-title">Edit/Remove Local Navigation Tags</h3>
                                </div>
                                    
                                    <!-- Modal body -->
                                    <div class="modal-body">
                                   

                                        <label style="margin:0;font-size:16px;color:black;"><strong>Local Nav Tag Title:</strong></label>
                                        <form name="ModalEditLocalNavTags" action="Edit_Local_Navigation_Tag.php" method="post">
                                            <input type="hidden" name="LocalTagEdit" value="'.$row["id"] . '">
                                            <input name="LocalNavTagEdit" style="width:100%;" type="text" autocomplete="off" value="'. $row["DeliverableLocalNavTagList"].'">
                                            <input style="float:right;color:white;background-color:blue;" type="submit" name="actionR" value="Update" />
                                            <input style="float:left;color:white;background-color:red;" type="submit" name="actionR" value="Delete" /></form>
                                            </form> 

                                    <br><br><br>
                                    
                                    <form style="margin-top:7px;" name="DeliverableModalForm" action="Add_Deliverable_Local.php" method="post">
                                        
                                        <label style="margin:0;font-size:16px;color:black;"><strong>Add Selected Deliverables To Web Page Tag:</strong></label><br>
                                        <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;"><input type="hidden" name="AddLocalTag" value="'. $row["DeliverableLocalNavTagList"]. '">
                                        ';

                                            $sql2 = "SELECT * FROM structure_deliverables WHERE  (DeliverableTitle IS NOT NULL AND DeliverableLocalNavTag IS NULL AND DeliverableGlobalNavTagList IS NULL) OR NOT DeliverableLocalNavTag = '". $row["DeliverableLocalNavTagList"]. "' ";
                                            $result2 = $connGlobal->query($sql2) or die($connGlobal->error);
                                            while($row2 = $result2->fetch_assoc()) {
                                                echo '<div style="border:black 2px solid;"><input type="checkbox" name="AddDeliverableLocal'.$row2["id"].'" value="'.$row2["id"].'">'.$row2["DeliverableTitle"].'</div>';
                                            }
                                            echo '
                                        </div>
                                        <input style="float:right;color:white;background-color:green;" type="submit" name="actionR" value="ADD" />
                                    </form> 
                                    <br>
                                    
                                    <form style="margin-top:7px;" name="RemoveModalForm" action="Remove_Deliverable_Local.php" method="post">
                                        
                                        <label style="margin:0;font-size:16px;color:black;"><strong>Remove Selected Deliverables From Web Page Tag:</strong></label><br>
                                        <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;">';
                                            $Counter = 0;
                                            $sql2 = "SELECT * FROM structure_deliverables WHERE  (DeliverableTitle IS NOT NULL AND DeliverableLocalNavTagList IS NULL AND DeliverableGlobalNavTagList IS NULL) AND DeliverableLocalNavTag = '". $row["DeliverableLocalNavTagList"]. "' ";
                                            $result2 = $connGlobal->query($sql2) or die($connGlobal->error);
                                                while($row2 = $result2->fetch_assoc()) {
                                                    $Counter = $Counter + 1;
                                                    echo '<div style="border:black 2px solid;"><input type="checkbox" name="RemoveDeliverable'.$row2["id"].'" value="'.$row2["id"].'">'.$row2["id"] . $row2["DeliverableTitle"].'</div>';
                                                }
                                            echo '
                                        </div>
                                        <input style="float:right;color:white;background-color:red;" type="submit" name="actionR" value="REMOVE" />
                                    </form> 
                                </div>
                                    
                                
                                    
                                </div>
                                </div>
                            </div>';
                        
                    }
                                    
                ?>
            </div> </div>
            </div> </div> 
                 

</body>

</html>