<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Title of the document</title>

<link rel="stylesheet" type="text/css" href="MetaBetaV2.0.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- Include external CSS. -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/codemirror.min.css">
 
    <!-- Include Editor style. -->
    <link href="Froala\css\froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
    <link href="Froala\css\froala_style.min.css" rel="stylesheet" type="text/css" />
  </head>
 
  <body>
 
    <!-- Include external JS libs. -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/codemirror.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/mode/xml/xml.min.js"></script>
 
    <!-- Include Editor JS files. -->
    <script type="text/javascript" src="Froala\js\froala_editor.pkgd.min.js"></script>
 
    <!-- Initialize the editor. -->
    <script> $(function() { $('.EditArea').froalaEditor() }); </script>

<style>
.EditArea{}
.fr-wrapper{resize: vertical;height:450px;overflow:scroll;overflow-x:hidden;}
</style>
</head>

<body>

    <!-- Side navigation -->
    <div class="sidenav" >
        <h3 style="color:black;">Objective List:</h3>
            <div style="overflow-x: hidden;overflow-y:scroll;height:1285px;">
                
                <?php
                        function OpenCon()
                        {
                        $dbhost = "localhost";
                        $dbuser = "root";
                        $dbpass = "";
                        $db = "MetaBeta";
                        $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
                        return $conn;
                        }
                        $conn = OpenCon();
                        //Create table if it doesnt already exist
                        $query = "SELECT ID FROM Strategic_Goals";
                        $result = mysqli_query($conn, $query);

                        if(empty($result)) {
                                        $query = "CREATE TABLE Strategic_Goals (
                                            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                                            ObjectiveTitle VARCHAR(600) NOT NULL,
                                            ObjectiveDescription VARCHAR(10000) NOT NULL,
                                            ObjectivePriority INT,
                                            ObjectiveQuestion VARCHAR(500),
                                            ObjectiveType VARCHAR(50)
                                            )";
                                        $result = mysqli_query($conn, $query);
                        }                                                                                                                   
                        
                        //Create table if it doesnt already exist
                        $query = "SELECT ID FROM Scope_Requirements";
                        $result = mysqli_query($conn, $query);

                        if(empty($result)) {
                                        $query = "CREATE TABLE Scope_Requirements (
                                            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                                            StrategyID INT,
                                            RequirementTitle TEXT(600) NOT NULL,
                                            RequirementDescription TEXT(10000) NOT NULL,
                                            RequirementType VARCHAR(2000),
                                            ObjectiveTitle VARCHAR(600) NOT NULL,
                                            ObjectiveDescription TEXT(10000) NOT NULL,
                                            ObjectivePriority INT,
                                            ObjectiveQuestion VARCHAR(500),
                                            ObjectiveType VARCHAR(50)
                                            )";
                                        
                                        if ($conn->query($query) === TRUE) {
                                            echo "New Table created successfully";
                                        } else {
                                            echo "Error: " . $query . "<br>" . $conn->error;
                                        }
                                    }
                
                        //Create table if it doesnt already exist
                        $query = "SELECT ID FROM Structure_Deliverables";
                        $result = mysqli_query($conn, $query);

                        if(empty($result)) {
                                        $query = "CREATE TABLE Structure_Deliverables (
                                            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                                            StrategyID INT,
                                            RequirementID INT,
                                            RequirementTitle TEXT(600),
                                            RequirementDescription TEXT(10000),
                                            RequirementType VARCHAR(2000),
                                            ObjectiveTitle VARCHAR(600) ,
                                            ObjectiveDescription TEXT(10000),
                                            ObjectivePriority INT,
                                            ObjectiveQuestion VARCHAR(500),
                                            ObjectiveType VARCHAR(50),
                                            DeliverableTitle TEXT(600),
                                            DeliverableCoreIdea TEXT(10000),
                                            DeliverableType VARCHAR(2000),
                                            DeliverableDeliveryMethod TEXT(10000),
                                            DeliverableGlobalNavTag VARCHAR(2000),
                                            DeliverableGlobalNavTagList VARCHAR(2000),
                                            DeliverableLocalNavTag VARCHAR(2000),
                                            DeliverableLocalNavTagList VARCHAR(2000)
                                            )";
                                        
                                        if ($conn->query($query) === TRUE) {
                                            echo "New Table created successfully";
                                        } else {
                                            echo "Error: " . $query . "<br>" . $conn->error;
                                        }
                                        
                        }
                        
                        $sqlDel = "SELECT * FROM Strategic_Goals ";
                        $Result1 = $conn->query($sqlDel);
                        while($row3 = $Result1->fetch_assoc()) 
                        {
                            if($_GET['activeObjective'] == $row3['id'])
                            {
                                echo "<strong><a id='".$row3['id']."' class='active' href='http://localhost/MetaBetaTest/MetaBetaV2.0.php?activeObjective=".$row3['id']."'>".$row3['ObjectiveTitle']."</a></strong>";
                            }
                            else
                            {
                                echo "<a id='".$row3['id']."' href='http://localhost/MetaBetaTest/MetaBetaV2.0.php?activeObjective=".$row3['id']."'>".$row3['ObjectiveTitle']."</a>";
                            }
                        }
                ?>
            </div>
    </div>

    <!-- Page content -->
    <div class="main" style="width:1500px;">
        
        <?php
            $ObjectiveID = (int)$_GET['activeObjective'];
            $conn = OpenCon();
            $sqlDel = "SELECT * FROM Strategic_Goals where id = '$ObjectiveID'";
            $Result1 = $conn->query($sqlDel);
            while($row3 = $Result1->fetch_assoc()) 
            {
                echo '<div class="row">
                        <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;text-decoration:underline;border:solid black 2px;background-color:#8d9390" type="button" data-toggle="modal" data-target="#myModal'. $row3["id"] . '">
                                <h3 style="float:left;">['.$row3['ObjectiveTitle'].']</h3>
                        </button>
                        <div class="modal" id="myModal'. $row3["id"] . '">
                            <div style="max-width:1200px !important;" class="modal-dialog">
                                  <div class="modal-content">
                                  
                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                      <h4 style="color: black !important;class="modal-title">Edit Strategic Objective:</h4>
                                      <button type="button" class="close" data-dismiss="modal">
                                      </button>
                                    </div>
                                    
                                    <!-- Modal body -->
                                    <div class="modal-body">                                                               
                                    <form name="Modalform" action="Delete_Strategy_Goal.php" method="post">
                                      <h5><strong>Original Question:</strong><br>'.$row3['ObjectiveQuestion'].'</h5>
                                       <input type="hidden" name="idDel" value="'.$row3["id"] . '">
                                       <label><strong>Priority:</strong></label><br>
                                       <select name="EditPriority">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                      </select><br>
                                       <label style="margin:0;font-size:16px;color:black;"><strong>Objective Title:</strong></label><input name="EditTitle" style="width:100%;" type="text" autocomplete="off" value="'. $row3["ObjectiveTitle"].'">
                                       <label style="margin:0;font-size:16px;color:black;"><strong>Objective Description:</strong></label><textarea  class="EditArea"  rows="5" name="EditDescription" style="resize:vertical;width:100%;" autocomplete="off">'. $row3["ObjectiveDescription"].'</textarea>
                                       <input style="clear:left;float:left;color:white;background-color:red;" type="submit" name="action" value="Delete" />
                                       <input style="float:right;color:white;background-color:blue;" type="submit" name="action" value="Update" />
                                       
                                    </form>
                                    </div>
                                    
                                  </div>
                                </div>
                              </div>
                    </div>
                <div class="row">
                    <div class="col-sm-6 " style="background-color:#bbbbbb;padding:0 !important;border: black 1px solid;">
                        <h2>'.$row3["ObjectiveType"] . ':</h2>
                        <div style="overflow-y:scroll; overflow-x:hidden;background-color:white;padding:0 !important;height:601px;width:100%;">
                            <h5>'.$row3["ObjectiveQuestion"] . '</h5>
                            <h5>Description:</h5>
                            <textarea   rows="80" name="EditDescription" style="resize:vertical;width:100%;" autocomplete="off">'. $row3["ObjectiveDescription"].'</textarea>
                        </div>
                    </div>
                    <div class="col-sm-6 " style="background-color:#bbbbbb;padding:0 !important;border: black 1px solid;">
                        <h2>List of Requirements:</h2>
                        <div style="overflow-y:scroll; overflow-x:hidden;background-color:white;padding:0 !important;height:601px;width:100%;">';
                            $sqlDel2 = "SELECT * FROM Scope_Requirements where StrategyID = '$ObjectiveID'";
                            $Result2 = $conn->query($sqlDel2);
                            while($row2 = $Result2->fetch_assoc()) 
                            {
                        echo'<div><button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:90%;border:solid black 2px;background-color:#b6a9b0" type="button" data-toggle="collapse" data-target="#Hidden2Req'. $row2["id"] . '">
                                        <strong>'. $row2["RequirementTitle"].'</strong>
                                    </button> 
                                    <button style="float:left;width:10%;" type="button" data-toggle="modal" data-target="#ReqEditModal'. $row2["id"] . '">Edit</button></div>
                                <div class="modal" id="ReqEditModal'. $row2["id"] . '">
                                    <div style="max-width:1200px !important;" class="modal-dialog">
                                    <div class="modal-content">
                                        
                                        <div class="modal-header">
                                            <h3 class="modal-title">Edit/Remove Requirement:</h3>
                                        </div>
                                            
                                            <!-- Modal body -->
                                        <div class="modal-body">
                                            
                                            <form name="ModalformReqEdit" action="Edit_Requirement.php" method="post">
                                                <label style="margin:0;margin-top:15px;"><strong>Reassign Requirement:</strong></label>

                                                <select name="StrategyObjectiveID" style="width:100%;max-height:50px;overflow:scroll;">
                                                
                                                <option style="background-color:#8d9390;" value=""></option>';
                                                    //Connect to DB
                                                    $connGlobal = OpenCon();
                                                    $query = "SELECT ID FROM Strategic_Goals";
                                                    $result = mysqli_query($connGlobal, $query);
                                                    $StratID12 = $_GET["activeObjective"];
                                                    $sql = "SELECT id, ObjectiveTitle, ObjectiveDescription, ObjectivePriority, ObjectiveType, ObjectiveQuestion FROM Strategic_Goals ";
                                                    $result = $connGlobal->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    // output data of each row
                                                    while($row = $result->fetch_assoc()) {
                                                        if($row["ObjectiveType"] === "Business Objective"){
                                                        echo '<option style="background-color:#8d9390;" value="'.$row["id"].'">'.$row["ObjectiveTitle"].'</option>
                                                        ';
                                                        }else{
                                                        echo '<option style="background-color:#b6a9b0;" value="'.$row["id"].'">'.$row["ObjectiveTitle"].'</option>
                                                        ';
                                                        }}};
    
                                                            
                                                echo'</select>
                                               
                                                    <label><strong>Requirement Type:<br></strong>'.$row2["RequirementType"].'</label><br>
                                                    <input type="hidden" name="ObjId" value="'.$row3["id"] . '">
                                                    <input type="hidden" name="ObjId" value="'.$row3["id"] . '"><input type="hidden" name="ReqId" value="'.$row2["id"] . '">
                                                    <label style="margin:0;font-size:16px;color:black;"><strong>Requirement Title:</strong></label><input name="EditReqTitle" style="width:100%;" type="text" autocomplete="off" value="'. $row2["RequirementTitle"].'">
                                                    <label style="margin:0;font-size:16px;color:black;"><strong>Requirement Description:</strong></label><textarea  class="EditArea" style="width:100%;height:450px;"  cols="63" rows="5" style="width:100%;"  name="RequirementDescription" style="resize:vertical" autocomplete="off">'. $row2["RequirementDescription"].'</textarea>
                                                    <input style="float:left;color:white;background-color:red;" type="submit" name="actionR" value="Delete" />
                                                    <input style="float:right;color:white;background-color:blue;" type="submit" name="actionR" value="Update" />
                                                    
                                            </form>
                                        </div>
                                            
                                        
                                            
                                    </div>
                                    </div>
                                </div>

                                    <div class="collapse" id="Hidden2Req'. $row2["id"] . '">';
                                    $sqlDel1 = "SELECT * FROM Structure_Deliverables where RequirementID = '". $row2["id"] ."'";
                                    $Result1 = $conn->query($sqlDel1);
                                    while($row1 = $Result1->fetch_assoc()) 
                                    {
                                        echo '                           
                                            <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="modal" data-target="#DeliveryEditModal'. $row1["id"] . '">
                                                <strong>'. $row1["DeliverableTitle"]. '</strong>
                                            </button>
                                            <div class="modal" id="DeliveryEditModal'. $row1["id"] . '">
                                            <div class="modal-dialog" style="max-width:1200px !important;">
                                            <div class="modal-content ">
                                            
                                            <div class="modal-header">
                                                <h3 class="modal-title">Edit/Remove Deliverable</h3>
                                            </div>
                                                
                                                <!-- Modal body -->
                                                <div class="modal-body">
                                                
                                                    
                                                    <form name="DeliverableModalForm" action="Edit_Deliverable.php" method="post">
                                                        <h3>'.$row1["RequirementTitle"] . '</h3></label><textarea style="width:100%;" cols="63" rows="5" name="ReqDesc" style="resize:vertical" autocomplete="off">'.$row1["RequirementDescription"] . '</textarea>
                                                        <br><h3><strong>'.$row1['DeliverableType'].':</strong></h3>
                                                        <input type="hidden" name="idDelReq" value="'.$row1["id"] . '">
                                                        <input type="hidden" name="idDelReq3" value="'.$row2["id"] . '">
                                                        <input type="hidden" name="idDelReq2" value="'.$row1["StrategyID"] . '">
                                                        <label style="margin:0;font-size:16px;color:black;"><strong>Delivery Title:</strong></label><input style="width:100%;" name="DeliverableTitle" style="width:100%;" type="text" autocomplete="off" value="'. $row1["DeliverableTitle"].'">
                                                        <label style="margin:0;font-size:16px;color:black;"><strong>Core Idea:</strong></label><textarea  class="EditArea" style="width:100%;" cols="63" rows="5" name="DeliverableCore" style="resize:vertical" autocomplete="off">'. $row1["DeliverableCoreIdea"].'</textarea>
                                                        <label style="margin:0;font-size:16px;color:black;"><strong>Delivery Method:</strong></label><textarea  class="EditArea" style="width:100%;" cols="63" rows="5" name="DeliverableDelivery" style="resize:vertical" autocomplete="off">'. $row1["DeliverableDeliveryMethod"].'</textarea>
                                                        <input style="float:left;color:white;background-color:red;" type="submit" name="actionR" value="Delete" />
                                                        <input style="float:right;color:white;background-color:blue;" type="submit" name="actionR" value="Update" />
                                                        
                                                    </form>
                                                </div>
                                                
                                            
                                                
                                            </div>
                                            </div>
                                        </div>'; 
                                    }
                                    echo '</div> ';
                            }
                            echo '
                        </div>
                    </div>
                </div>
                ';
            }
        ?>        
        <div class="row">
            <div class="col-sm-3 " style="background-color:#bbbbbb;padding:0 !important;border: black 1px solid;margin:150px;margin-left:5px;margin-right:5px;">
                <button style="height:50px;font-size:19px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:center;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="modal" data-target="#NewOjective">
                    <strong>New Objective</strong>
                </button>
                <div class="modal" id="NewOjective">
                    <div style="max-width:1200px !important;" class="modal-dialog">
                        <div class="modal-content">
                                                    
                            <div class="modal-header">
                                <h3 class="modal-title">Create a New Objective:</h3>
                            </div>
                                            
                                                        <!-- Modal body -->
                            <div class="modal-body">
                                <form  style="width:100%;" name="UserObjForm" onsubmit="return validateU()" action="Submit User Objective.php" method="post" >
                                    <div style="background-color:#b6a9b0"><h4 style="margin:0 !important;width:100%;color:black !important;">User Needs:</h4>
                                        <select  style="width:100%;" name="Strat_User_Questions">
                                            <option value="How is the Need/ Problem/ Opportunity Defined by the prospect?">How is the Need/ Problem/ Opportunity Defined by the user?</option>
                                            <option value="Prospects' product related search-engine behavior:">Users' product related search-engine behavior?</option>
                                            <option value="Concerns/ Questions the prospect will have about your product?">Concerns/ Questions the prospect will have about your product?</option>
                                            <option value="What does the prospect desire?">What does the user desire?</option>
                                            <option value="What does the user need to accomplish using this application?">What does the user need to accomplish using this application?</option>
                                            <option value="Who is going to be using this application?">Who is going to be using this application?</option>
                                        </select>
                                        <label style="margin:0;font-size:19px;color:black !important;"><strong>Objective Description:</strong></label><br>
                                        <textarea  class="EditArea" style="width:100%;" cols="85" rows="5" name="Strat_UserNeedDescription" style="resize:vertical" autocomplete="off"></textarea><br>
                                        <label style="margin:0;font-size:19px;color:black !important;"><strong>Objective Title:</strong></label><br><input name="Strat_UserNeedTitle" autocomplete="off" style="width:100%;" type="text"><br>
                                        <label style="margin:0;font-size:19px;color:black !important;"><strong>Priority:</strong></label>
                                        <select name="Strat_User_Priority">
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                        </select>
                                        <input type="hidden" name="idDel0" value="<?php echo $_GET["activeObjective"]?>">
                                        <input type="submit" style="float:right;" value="Submit"><br><br>
                                    </div>
                                </form>
                                <form style="width:100%;" name="BusinessObjForm" action="Submit Business Objective.php" method="post" onsubmit="return validate();">
                                    <div style="background-color:#8d9390;padding-bottom:8px;"><h4 style="color:black !important;margin:0 !important;border: black 1px solid;">Business Objectives:</h4>
                                            <select style="width:100%;" name="Strat_BOquestions">
                                                    <option value="What do I want the website to offer?">What do I want the project to offer?</option>
                                                    <option value="What do I want the project to accomplish?">What do I want the project to accomplish?</option>
                                                    <option value="Message or Information I wish to convey?">Message, offer, or content the website should convey?</option>
                                                    <option value="Who's typically going to visit the site? What are they expecting to accomplish?">Who's typically going to visit the site? What are they expecting to accomplish?</option>
                                            </select>
                                            <label style="margin:0;font-size:19px;color:black !important;"><strong>Objective Description:</strong></label><br>
                                            <textarea  class="EditArea" style="width:100%;" cols="85" rows="5" name="Strat_BOdescription" style="resize:vertical" autocomplete="off"></textarea><br>
                                            <label style="margin:0;font-size:19px;color:black !important;"><strong>Objective Title:</strong></label><br><input name="Strat_BOtitle" style="width:100%;" type="text" autocomplete="off"><br>
                                            <label style="margin:0;font-size:19px;color:black !important;"><strong>Priority:Low(1) - High(10)</strong></label>
                                            <select name="Strat_BOpriority">
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                            </select>
                                            <input type="hidden" name="idDel0" value="<?php echo $_GET["activeObjective"]?>">
                                            <input type="submit" style="float:right;" value="Submit">
                                    </div>
                                </form> 
                            </div>       
                        </div>

                    </div>
            </div>
            
        </div>
        <div class="col-sm-3 " style="background-color:#bbbbbb;padding:0 !important;border: black 1px solid;margin:150px;margin-right:20px;margin-right:5px;">
                <button style="height:50px;font-size:19px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:center;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="modal" data-target="#NewRequirement">
                    <strong>Create a Requirement for this Objective:</strong>
                </button>
                <div class="modal" id="NewRequirement">
                    <div style="max-width:1200px !important;" class="modal-dialog">
                        <div class="modal-content">
                                                    
                            <div class="modal-header">
                                <h3 class="modal-title">Define a New Requirement:</h3>
                            </div>
                                            
                                                        <!-- Modal body -->
                            <div class="modal-body">
                            <form name="RequirementForm" action="Submit Requirement.php"style="background-color:#9b88b8" method="post" >
                                <div style="padding-bottom:30px;">
                                
                                    <input type="hidden" name="idDel10" value="<?php echo $_GET["activeObjective"];?> ">
                                    <label style="margin:0;font-size:16px;"><strong>Requirement Title:</strong></label><br><input name="RequirementTitle" style="width:100%;" type="text" autocomplete="off"><br>
                                    <label style="margin:0;font-size:16px;"><strong>Requirement Type:</strong></label>
                                    <select name="RequirementType" style="width:100%;margin:0;margin-top:5px;">
                                            <option value="Objective - What does the user want to accomplish?">"Objective" - What does the user want to accomplish?</option>
                                            <option value="Functional - What does the user need to do in order reach their objective?">"Functional" - What does the user need to do in order reach their objective?</option>
                                            <option value="Technical - What are the technical constraints of this Strategic Objective? What resources are needed to get this done?">"Technical" - What are the technical constraints of this Strategic Objective? What resources are needed to get this done?</option>
                                            <option value="BusinessRules -   What external constraints does the project need to abide by? (legal, contractual, etc)">"BusinessRules" -   What external constraints does the project need to abide by? (legal, contractual, etc)</option>
                                    </select>
                                    <label style="margin:0;font-size:16px;"><strong>Description:</strong></label><br>
                                    <textarea  class="EditArea" cols="85" style="height:900px;width:100%;" rows="5" name="RequirementDescription" style="resize:vertical;width:100%;" autocomplete="off"></textarea><br>
                                    <input type="submit" style="float:right;" value="Submit">
                                </div>
                            </form>
                            </div>       
                        </div>

                    </div>
            </div>
        </div>
        <div class="col-sm-3 " style="background-color:#bbbbbb;padding:0 !important;border: black 1px solid;margin:150px;margin-right:25px;margin-right:25px;">
                <button style="height:50px;font-size:19px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:center;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="modal" data-target="#NewDeliverable">
                    <strong>Create a Deliverable for this Objective:</strong>
                </button>
                <div class="modal" id="NewDeliverable">
                    <div style="max-width:1200px !important;" class="modal-dialog">
                        <div class="modal-content">
                                                    
                            <div class="modal-header">
                                <h3 class="modal-title">Create a New Deliverable:</h3>
                            </div>
                                            
                                                        <!-- Modal body -->
                            <div class="modal-body">
                            <form name="DeliverableForm" action="Submit Deliverable.php" method="post" >
                                <div style="background-color:#679e97"><h4 style="margin:0 !important;color:black !important;">Define a Deliverable:</h4>
                                    <label style="color:white !important;margin:0;margin-top:15px;"><strong >Which requirement is this deliverable tailored for?</strong></label>
                                    
                                    <select name="RequirementDeliverable" style="width:100%;">
                                    
                                    <?php
                                        //Connect to DB
                                        $connGlobal = OpenCon();
                                        $ObjID = (int)$_GET["activeObjective"];
                                        $sql = "SELECT * FROM Scope_Requirements WHERE StrategyID = '$ObjID' ";
                                        $result = $connGlobal->query($sql);
                                        if ($result->num_rows > 0) {
                                        // output data of each row
                                            
                                            while($row = $result->fetch_assoc()) 
                                            {
                                            echo '<option value="'.$row["id"].'">'.$row["RequirementTitle"].'</option>';
                                            }
                                            $Page = $_GET['activeObjective'] ;
                                            
                                            echo '</select><br>
                                            <label style="margin:0;font-size:16px;color:white !important;"><strong>Type of Deliverable:</strong></label><br>
                                            <input type="hidden" name="idDel4" value="'.$_GET["activeObjective"].'">';
                                            }
                                        ?>  
                                                
                                    <select style="width:100%;"name="DeliverableType">
                                        <option value="Content Deliverable">Content Deliverable</option>
                                        <option value="Project Functionality">Project Feature Proposal</option>
                                        <option value="General Solution">General Solution</option>
                                    
                                    </select>
                                    <label style="margin:0;font-size:16px;color:white !important;"><strong>Describe the Core Idea:</strong></label><br>
                                    <textarea class="EditArea" cols="85" rows="5" name="Core_Idea" style="resize:vertical;width:100%;" autocomplete="off"></textarea><br>
                                    <label style="margin:0;font-size:16px;color:white !important;"><strong>Title this Deliverable:</strong></label><br>
                                    <input name="DeliverableTitle" autocomplete="off" style="width:100%;" type="text"><br>
                                    <label style="margin:0;font-size:16px;color:white !important;"><strong>How are we going to deliver/ display this content?</strong></label><br>
                                    <textarea  class="EditArea" cols="85" rows="5" name="DeliveryMethod" style="resize:vertical;width:100%;" autocomplete="off"></textarea><br>
                                    
                                    <input type="submit" style="float:right;" value="Submit"><br><br>
                                </div>
                            </form> 
                            </div>       
                        </div>

                    </div>
            </div>
        </div>
        </div>
        <div class="row footer" style="margin-left: 505px;">
            <div class="col-sm-3 "><a href="GenerateKeyLegend.php">Wire Frame Key-Legend</a></div>
            <div class="col-sm-3 "><a href="GenerateSiteMapNodes.php">Nodes for Site Map</a></div>
            <div class="col-sm-3 "><a href="GenerateObjReqDel.php">|Obj|Req|Del|</a></div>
            <div class="col-sm-3 "><a href="GenerateGoalReqDeliverable.php">Generate Goal>Req>Del Outline</a></div>
        </div> 
        
    </div>
    <div class="container" style="display:block;background-color:black;height:100%;position:fixed;top:0;left:2010px;width:550px;padding:0;">
        <div class="row" style="background-color:white;height:50%;width:100%;margin:0;">
            <div class="col-sm-12 Form_Container" style="padding:0;">
            <div>
                <h4 style="margin:0 !important;color:white;background-color:black !important;">Global Navigation Tags:</h4>
            </div>
            <form name="CreateGlobalTag" action="Create Global Tag.php" method="post" >
                <label style="margin:0;font-size:16px;color:black !important;"><strong>Create a webpage to host deliverables:</strong></label><br>
                <input type="hidden" name="ObjectiveID" value="<?php echo $_GET["activeObjective"]; ?>">
                <input name="GlobalTagTitle" autocomplete="off" style="width:100%;" type="text"><br>
                <input type="submit" style="float:right;" value="Submit"><br><br>
            </form>
        
            <label style="margin:0;font-size:16px;color:black !important;"><strong>Edit/ Remove Webpages:</strong></label><br>
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:510px;">
                <?php
                    
                        $connGlobal = OpenCon();
                        
                        $sql = "SELECT * FROM structure_deliverables WHERE DeliverableGlobalNavTagList IS NOT NULL AND DeliverableType IS NULL";
                        $result = $connGlobal->query($sql);
                        while($row = $result->fetch_assoc()) {
                            echo '                           
                            <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;padding-left:30px;" type="button" data-toggle="modal" data-target="#TagEditModal'. $row["id"] . '">
                                <strong>'. $row["DeliverableGlobalNavTagList"]. '</strong>
                            </button>';
                            
                            
                                echo 
                                '<div class="modal" id="TagEditModal'. $row["id"] . '">
                                <div style="max-width:1200px !important;" class="modal-dialog">
                                <div class="modal-content">
                                
                                <div class="modal-header">
                                    <h3 class="modal-title">Edit/Remove Global Navigation Tags</h3>
                                </div>
                                    
                                    <!-- Modal body -->
                                    <div class="modal-body">
                                   

                                        <label style="margin:0;font-size:16px;color:black;"><strong>Global Nav Tag Title:</strong></label>
                                        <form name="ModalEditGlobalNavTags" action="Edit_Global_Navigation_Tag.php" method="post">
                                            <input type="hidden" name="idDelReq" value="'.$row["id"] . '">
                                            <input type="hidden" name="ObjectiveID" value="'. $_GET["activeObjective"].'">  
                                            <input name="GlobalNavTagEdit" style="width:100%;" type="text" autocomplete="off" value="'. $row["DeliverableGlobalNavTagList"].'">
                                            <input style="float:right;color:white;background-color:blue;" type="submit" name="actionR" value="Update" />
                                            <input style="float:left;color:white;background-color:red;" type="submit" name="actionR" value="Delete" /></form>
                                            </form> 

                                    <br><br><br>
                                    
                                    <form style="margin-top:7px;" name="DeliverableModalForm" action="Add_Deliverable_Global.php" method="post">
                                        <input type="hidden" name="AddGlobalTag" value="'. $row["DeliverableGlobalNavTagList"]. '">
                                        <input type="hidden" name="ObjectiveID" value="'. $_GET["activeObjective"].'"> 
                                        <label style="margin:0;font-size:16px;color:black;"><strong>Add Selected Deliverables To Web Page Tag:</strong></label><br>
                                        <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;"><input type="hidden" name="AddGlobalTag" value="'. $row["DeliverableGlobalNavTagList"]. '">
                                        ';
//Check box Local Grouping Condition
                                            $sql5 = "SELECT * FROM structure_deliverables WHERE (DeliverableTitle IS NULL AND DeliverableLocalNavTagList IS NOT NULL AND DeliverableGlobalNavTag IS NULL) OR
                                            (DeliverableTitle IS NULL AND DeliverableLocalNavTagList IS NOT NULL AND DeliverableGlobalNavTag IS NULL)";
                                            $result5 = $connGlobal->query($sql5) or die($connGlobal->error);
                                            while($row5 = $result5->fetch_assoc()) {
                                                echo '<div style="border:solid black 2px;background-color:#29A5FF">
                                                      <input type="checkbox" name="AddLocalTagToGlobal'.$row5["id"].'" value="'.$row5["id"].'"><strong>'.$row5["DeliverableLocalNavTagList"].'</strong><br>';

                                                    $sql4 = "SELECT * FROM structure_deliverables WHERE (DeliverableTitle IS NOT NULL AND DeliverableLocalNavTag ='".$row5["DeliverableLocalNavTagList"]."')" ;
                                                    $result4 = $connGlobal->query($sql4) or die($connGlobal->error);
                                                    while($row4 = $result4->fetch_assoc()) {
                                                        
                                                            echo '<div style="border-bottom:solid black 1px;padding-left:30px;background-color:#99DFFF;width:100%;">'.$row4["DeliverableTitle"].'</div>';
                                                        }
                                                echo '</div>';        
                                            }
                                            
                                        $sql2 = "SELECT * FROM structure_deliverables WHERE  (StrategyID = '".(int)$_GET["activeObjective"]."' AND DeliverableTitle IS NOT NULL AND DeliverableLocalNavTag IS NULL AND DeliverableGlobalNavTag IS NULL ) OR (DeliverableTitle IS NOT NULL AND NOT DeliverableGlobalNavTag = '". $row["DeliverableGlobalNavTagList"]. "' AND DeliverableLocalNavTag IS NULL) ";
                                        $result3 = $connGlobal->query($sql2) or die($connGlobal->error);
                                            while($row3 = $result3->fetch_assoc()) {
                                                echo '<div style="background-color:#679e97;border:black 2px solid;"><strong><input type="checkbox" name="AddDeliverable'.$row3["id"].'" value="'.$row3["id"].'">'.$row3["DeliverableTitle"].'</strong></div>';
                                            }
                                            echo '
                                        </div>
                                        <input style="float:right;color:white;background-color:green;" type="submit" name="actionR" value="ADD" />
                                    </form> 
                                    <br>
                                    
                                    <form style="margin-top:7px;" name="RemoveModalForm" action="Remove_Deliverable_Global.php" method="post">
                                    <input type="hidden" name="ObjectiveID" value="'. $_GET["activeObjective"].'"> 
                                        <label style="margin:0;font-size:16px;color:black;"><strong>Remove Selected Deliverables From Web Page Tag:</strong></label><br>
                                        <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;">';
                                            
                                            $sql5 = "SELECT * FROM structure_deliverables WHERE (DeliverableTitle IS NULL AND DeliverableLocalNavTagList IS NOT NULL AND DeliverableGlobalNavTag = '". $row["DeliverableGlobalNavTagList"]."' )";
                                            $result5 = $connGlobal->query($sql5) or die($connGlobal->error);
                                            while($row5 = $result5->fetch_assoc()) {
                                                echo '<div style="border:solid black 2px;background-color:#29A5FF">
                                                      <input type="checkbox" name="AddLocalTagToGlobal'.$row5["id"].'" value="'.$row5["id"].'"><strong>'.$row5["DeliverableLocalNavTagList"].'</strong><br>';

                                                    $sql4 = "SELECT * FROM structure_deliverables WHERE (DeliverableTitle IS NOT NULL AND DeliverableLocalNavTag ='".$row5["DeliverableLocalNavTagList"]."')" ;
                                                    $result4 = $connGlobal->query($sql4) or die($connGlobal->error);
                                                    while($row4 = $result4->fetch_assoc()) {
                                                        
                                                            echo '<div style="border-bottom:solid black 1px;padding-left:30px;background-color:#99DFFF;width:100%;">'.$row4["DeliverableTitle"].'</div>';
                                                        }
                                                echo '</div>';        
                                            }
                                            $sql2 = "SELECT * FROM structure_deliverables WHERE (DeliverableGlobalNavTag='". $row["DeliverableGlobalNavTagList"]. "' AND DeliverableLocalNavTag IS NULL AND DeliverableTitle IS NOT NULL)";
                                            $result2 = $connGlobal->query($sql2) or die($connGlobal->error);
                                                while($row2 = $result2->fetch_assoc()) {
                                                    echo '<div style=background-color:#679e97;border:black 2px solid;"><input type="checkbox" name="RemoveDeliverable'.$row2["id"].'" value="'.$row2["id"].'"><strong>'.$row2["DeliverableTitle"].'</strong></div>';
                                                }    
                                            echo '
                                        </div>
                                        <input style="float:right;color:white;background-color:red;" type="submit" name="actionR" value="REMOVE" />
                                    </form> 
                                </div>
                                    
                                
                                    
                                </div>
                                </div>
                            </div>';
                        
                    }
                                    
                ?>
            </div> </div>                               
            </div>
            <div class="row">
            <div class="col-sm-12 Form_Container" style="">
                <div>
                    <h4 style="margin:0 !important;color:white;background-color:black !important;">Local Navigation Tags:</h4>
                </div>
            <form style="margin:0 !important;color:white;background-color:white !important;" name="CreateLocalTag" action="Create Local Tag.php" method="post" >
                <label style="margin:0;font-size:16px;color:black !important;"><strong>Create a group name for deliverables:</strong></label><br>
                    <input name="LocalTagTitle" autocomplete="off" style="width:100%;" type="text"><br>
                    <input type="hidden" name="ObjectiveID" value="<?php echo $_GET["activeObjective"]; ?>">
                    <input type="submit" style="float:right;" value="Submit"><br><br>
            </form>
            
                <label style="margin:0;width:100%;font-size:16px;color:black !important;background-color:white;"><strong>Edit/ Remove Local Groupings:</strong></label><br>
                <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:511px;">
                    <?php
                        $connGlobal = OpenCon();
                            
                            $sql = "SELECT * FROM structure_deliverables WHERE DeliverableLocalNavTagList IS NOT NULL AND DeliverableType IS NULL";
                            $result = $connGlobal->query($sql);
                            while($row = $result->fetch_assoc()) {
                                echo '                           
                                <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#29A5FF;padding-left:30px;" type="button" data-toggle="modal" data-target="#TagEditModal'. $row["id"] . '">
                                    <strong>'. $row["DeliverableLocalNavTagList"]. '</strong>
                                </button>';
                                
                                
                                    echo 
                                    '<div class="modal" id="TagEditModal'. $row["id"] . '">
                                    <div style="max-width:1200px !important;" class="modal-dialog">
                                    <div class="modal-content">
                                    
                                    <div class="modal-header">
                                        <h3 class="modal-title">Edit/Remove Local Navigation Tags</h3>
                                    </div>
                                        
                                        <!-- Modal body -->
                                        <div class="modal-body">
                                    

                                            <label style="margin:0;font-size:16px;color:black;"><strong>Local Nav Tag Title:</strong></label>
                                            <form name="ModalEditLocalNavTags" action="Edit_Local_Navigation_Tag.php" method="post">
                                            <input type="hidden" name="idDelReq" value="'.$row["id"] . '">
                                            <input type="hidden" name="ObjectiveID" value="'. $_GET["activeObjective"].'">  
                                                <input type="hidden" name="LocalTagEdit" value="'.$row["id"] . '">
                                                <input name="LocalNavTagEdit" style="width:100%;" type="text" autocomplete="off" value="'. $row["DeliverableLocalNavTagList"].'">
                                                <input style="float:right;color:white;background-color:blue;" type="submit" name="actionR" value="Update" />
                                                <input style="float:left;color:white;background-color:red;" type="submit" name="actionR" value="Delete" /></form>
                                                </form> 

                                        <br><br><br>
                                        
                                        <form style="margin-top:7px;" name="DeliverableModalForm" action="Add_Deliverable_Local.php" method="post">
                                        <input type="hidden" name="ObjectiveID" value="'. $_GET["activeObjective"].'"> 
                                            <label style="margin:0;font-size:16px;color:black;"><strong>Add Selected Deliverables To Web Page Tag:</strong></label><br>
                                            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;"><input type="hidden" name="AddLocalTag" value="'. $row["DeliverableLocalNavTagList"]. '">
                                            ';
                                                $ObjectiveId = (int)$_GET['activeObjective'];
                                                $sql2 = "SELECT * FROM structure_deliverables WHERE  (StrategyID = $ObjectiveId AND DeliverableTitle IS NOT NULL AND DeliverableLocalNavTag IS NULL AND DeliverableGlobalNavTagList IS NULL)  ";
                                                $result2 = $connGlobal->query($sql2) or die($connGlobal->error);
                                                while($row2 = $result2->fetch_assoc()) {
                                                    echo '<div style="border:black 2px solid;background-color:#679e97;"><input type="checkbox" name="AddDeliverableLocal'.$row2["id"].'" value="'.$row2["id"].'">'.$row2["DeliverableTitle"].'</div>';
                                                }
                                                echo '
                                            </div>
                                            <input style="float:right;color:white;background-color:green;" type="submit" name="actionR" value="ADD" />
                                        </form> 
                                        <br>
                                        
                                        <form style="margin-top:7px;" name="RemoveModalForm" action="Remove_Deliverable_Local.php" method="post">
                                        <input type="hidden" name="ObjectiveID" value="'. $_GET["activeObjective"].'"> 
                                            <label style="margin:0;font-size:16px;color:black;"><strong>Remove Selected Deliverables From Web Page Tag:</strong></label><br>
                                            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;">';
                                                $Counter = 0;
                                                $sql2 = "SELECT * FROM structure_deliverables WHERE  (DeliverableTitle IS NOT NULL AND DeliverableLocalNavTagList IS NULL AND DeliverableGlobalNavTagList IS NULL) AND DeliverableLocalNavTag = '". $row["DeliverableLocalNavTagList"]. "' ";
                                                $result2 = $connGlobal->query($sql2) or die($connGlobal->error);
                                                    while($row2 = $result2->fetch_assoc()) {
                                                        $Counter = $Counter + 1;
                                                        echo '<div style="border:black 2px solid;background-color:#679e97;"><input type="checkbox" name="RemoveDeliverable'.$row2["id"].'" value="'.$row2["id"].'">'. $row2["DeliverableTitle"].'</div>';
                                                    }
                                                echo '
                                            </div>
                                            <input style="float:right;color:white;background-color:red;" type="submit" name="actionR" value="REMOVE" />
                                        </form> 
                                    </div>
                                        
                                    
                                        
                                    </div>
                                    </div>
                                </div>';
                            
                        }
                                        
                    ?>
            </div> </div>
            </div>
    </div> 
            

          
</body>
</html>