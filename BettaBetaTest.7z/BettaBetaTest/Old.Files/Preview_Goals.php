<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Title of the document</title>

<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</head>

<body>
<div class="container" style="max-width: 2040px;">
    
            <?php
            function OpenCon()
            {
            $dbhost = "localhost";
            $dbuser = "root";
            $dbpass = "";
            $db = "MetaBeta";
            
            
            $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
            
            return $conn;
            }
            $conn = OpenCon();
            $sqlDel = "SELECT * FROM Strategic_Goals ";
            $Result1 = $conn->query($sqlDel);
            $count = 2;
            while($row3 = $Result1->fetch_assoc()) {
                if($count%2 == 0)
                {
                    if($row3['ObjectiveType'] === "User Objective" )
                    {
                            echo  '<div class="row"> 
                                        <div style="border:2px solid black;" class="col-sm-6 Form_Container" >
                                        <div style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;"><h3 style="background-color:#b6a9b0;margin:0;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">'.$row3['ObjectiveTitle'].'</h3></div>
                                                <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100px;background-color:#E1D5DE;">

                                                    <h5>'.$row3['ObjectiveDescription'].' </h5>
                                                </div> <h5 style="color:black !important;background-color:#BBBAFA;margin:0;">Requirements: </h5>
                                            ';
                        $sqlDel2 = "SELECT * FROM scope_requirements WHERE StrategyID ='" .$row3['id']."'";
                        $Result2 = $conn->query($sqlDel2);
                        while($row = $Result2->fetch_assoc()) 
                        {
                            echo' <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#7b6eae;padding-left:30px;" type="button" data-toggle="collapse" data-target="#HiddenRequirement'. $row["id"] . '">
                                <strong>'. $row["RequirementTitle"]. '</strong>
                            </button>
                                    
                            <div class="collapse" id="HiddenRequirement'. $row["id"] . '">
                            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#BBBAFA;padding-left:30px;"height:100px;">
                            '. $row["RequirementType"]. '<br>'. $row["RequirementDescription"].'</div><h5 style="background-color:#96E5DB;margin:0;padding-left:30px;">Deliverables: </h5>';
                            
                            $sqlDel5 = "SELECT * FROM Structure_Deliverables WHERE RequirementID ='" .$row['id']."'";
                            $Result5 = $conn->query($sqlDel5);
                            while($row5= $Result5->fetch_assoc()) 
                            {
                                echo'
                                <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;padding-left:60px;" type="button" data-toggle="collapse" data-target="#HiddenDeliverables'. $row5["id"] . '">
                                <strong>'. $row5["DeliverableTitle"]. '</strong>
                                </button>
                                <div class="collapse" id="HiddenDeliverables'. $row5["id"] . '"><div  style="overflow-y:scroll; overflow-x:hidden;background-color:#96E5DB;padding-left:60px;"height:100px;">
                                '. $row5["DeliverableType"]. '<br><br>'. $row5["DeliverableCoreIdea"]. '<br><br>'. $row5["DeliverableDeliveryMethod"]. '
                                </div></div>
                                ';
                            }
                            echo '</div>';
                        }
                        
                        echo '</div>'; 
                        $count = 1;
                    }else{
                        echo  '<div class="row"> 
                                        <div class="col-sm-6 Form_Container" style="">
                                            <h3 style="background-color:#8d9390;margin:0;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">'.$row3['ObjectiveTitle'].'</h3>
                                                <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100px;background-color:#B2D6C6;">

                                                    <h5>'.$row3['ObjectiveDescription'].' </h5>
                                                </div> <h5 style="color:black !important;background-color:#BBBAFA;margin:0;">Requirements: </h5>
                                            ';
                        $sqlDel2 = "SELECT * FROM scope_requirements WHERE StrategyID ='" .$row3['id']."'";
                        $Result2 = $conn->query($sqlDel2);
                        while($row = $Result2->fetch_assoc()) 
                        {
                            echo' <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#7b6eae;padding-left:30px;" type="button" data-toggle="collapse" data-target="#HiddenRequirement'. $row["id"] . '">
                                <strong>'. $row["RequirementTitle"]. '</strong>
                            </button>
                                    
                            <div class="collapse" id="HiddenRequirement'. $row["id"] . '">
                            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#BBBAFA;padding-left:30px;"height:100px;">
                            '. $row["RequirementType"]. '<br>'. $row["RequirementDescription"].'</div><h5 style="background-color:#96E5DB;margin:0;padding-left:30px;">Deliverables: </h5>';
                            
                            $sqlDel5 = "SELECT * FROM Structure_Deliverables WHERE RequirementID ='" .$row['id']."'";
                            $Result5 = $conn->query($sqlDel5);
                            while($row5= $Result5->fetch_assoc()) 
                            {
                                echo'
                                <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;padding-left:60px;" type="button" data-toggle="collapse" data-target="#HiddenDeliverables'. $row5["id"] . '">
                                <strong>'. $row5["DeliverableTitle"]. '</strong>
                                </button>
                                <div class="collapse" id="HiddenDeliverables'. $row5["id"] . '"><div  style="overflow-y:scroll; overflow-x:hidden;background-color:#96E5DB;padding-left:60px;"height:100px;">
                                '. $row5["DeliverableType"]. '<br><br>'. $row5["DeliverableCoreIdea"]. '<br><br>'. $row5["DeliverableDeliveryMethod"]. '
                                </div></div>
                                ';
                            }
                            echo '</div>';
                        }
                        
                        echo '</div>'; 
                        $count = 1;
                    }  
                }else
                {
                    if($row3['ObjectiveType'] === "User Objective" )
                    {
                            echo  '
                                        <div class="col-sm-6 Form_Container" style="">
                                        <h3 style="background-color:#b6a9b0;margin:0;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">'.$row3['ObjectiveTitle'].'</h3>
                                                <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100px;background-color:#E1D5DE;">

                                                    <h5>'.$row3['ObjectiveDescription'].' </h5>
                                                </div> <h5 style="color:black !important;background-color:#BBBAFA;margin:0;">Requirements: </h5>
                                            ';
                        $sqlDel2 = "SELECT * FROM scope_requirements WHERE StrategyID ='" .$row3['id']."'";
                        $Result2 = $conn->query($sqlDel2);
                        while($row = $Result2->fetch_assoc()) 
                        {
                            echo' <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#7b6eae;padding-left:30px;" type="button" data-toggle="collapse" data-target="#HiddenRequirement'. $row["id"] . '">
                                <strong>'. $row["RequirementTitle"]. '</strong>
                            </button>
                                    
                            <div class="collapse" id="HiddenRequirement'. $row["id"] . '">
                            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#BBBAFA;padding-left:30px;"height:100px;">
                            '. $row["RequirementType"]. '<br>'. $row["RequirementDescription"].'</div><h5 style="background-color:#96E5DB;margin:0;padding-left:30px;">Deliverables: </h5>';
                            
                            $sqlDel5 = "SELECT * FROM Structure_Deliverables WHERE RequirementID ='" .$row['id']."'";
                            $Result5 = $conn->query($sqlDel5);
                            while($row5= $Result5->fetch_assoc()) 
                            {
                                echo'
                                <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;padding-left:60px;" type="button" data-toggle="collapse" data-target="#HiddenDeliverables'. $row5["id"] . '">
                                <strong>'. $row5["DeliverableTitle"]. '</strong>
                                </button>
                                <div class="collapse" id="HiddenDeliverables'. $row5["id"] . '"><div  style="overflow-y:scroll; overflow-x:hidden;background-color:#96E5DB;padding-left:60px;"height:100px;">
                                '. $row5["DeliverableType"]. '<br><br>'. $row5["DeliverableCoreIdea"]. '<br><br>'. $row5["DeliverableDeliveryMethod"]. '
                                </div></div>
                                ';
                            }
                            echo '</div>';
                        }
                        
                        echo '</div>'; 
                        $count = 1;
                    }else{
                        echo  '
                                        <div class="col-sm-6 Form_Container" style="">
                                            <h3 style="background-color:#8d9390;margin:0;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">'.$row3['ObjectiveTitle'].'</h3>
                                                <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:100px;background-color:#B2D6C6;">

                                                    <h5>'.$row3['ObjectiveDescription'].' </h5>
                                                </div> <h5 style="color:black !important;background-color:#BBBAFA;margin:0;">Requirements: </h5>
                                            ';
                        $sqlDel2 = "SELECT * FROM scope_requirements WHERE StrategyID ='" .$row3['id']."'";
                        $Result2 = $conn->query($sqlDel2);
                        while($row = $Result2->fetch_assoc()) 
                        {
                            echo' <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#7b6eae;padding-left:30px;" type="button" data-toggle="collapse" data-target="#HiddenRequirement'. $row["id"] . '">
                                <strong>'. $row["RequirementTitle"]. '</strong>
                            </button>
                                    
                            <div class="collapse" id="HiddenRequirement'. $row["id"] . '">
                            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#BBBAFA;padding-left:30px;"height:100px;">
                            '. $row["RequirementType"]. '<br>'. $row["RequirementDescription"].'</div><h5 style="background-color:#96E5DB;margin:0;padding-left:30px;">Deliverables: </h5>';
                            
                            $sqlDel5 = "SELECT * FROM Structure_Deliverables WHERE RequirementID ='" .$row['id']."'";
                            $Result5 = $conn->query($sqlDel5);
                            while($row5= $Result5->fetch_assoc()) 
                            {
                                echo'
                                <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;padding-left:60px;" type="button" data-toggle="collapse" data-target="#HiddenDeliverables'. $row5["id"] . '">
                                <strong>'. $row5["DeliverableTitle"]. '</strong>
                                </button>
                                <div class="collapse" id="HiddenDeliverables'. $row5["id"] . '"><div  style="overflow-y:scroll; overflow-x:hidden;background-color:#96E5DB;padding-left:60px;"height:100px;">
                                '. $row5["DeliverableType"]. '<br><br>'. $row5["DeliverableCoreIdea"]. '<br><br>'. $row5["DeliverableDeliveryMethod"]. '
                                </div></div>
                                ';
                            }
                            echo '</div>';
                        }
                        
                        echo '</div>'; 
                        $count = 1;
                    }
                }
            }


            ?>
</body>