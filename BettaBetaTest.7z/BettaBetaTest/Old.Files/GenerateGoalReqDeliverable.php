<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Project Outline</title>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</head>

<body >
<div class="navbar  "  style="padding:0;position:fixed;z-index:11;bottom:0;width:100%;">
                <button style="width:100%;margin:0;padding:0;font-size:30px;text-decoration:underline;float:right;color:white;background-color:red;" type="button" data-toggle="collapse" data-target="#ToC">
                    <strong style="width:100%;">TABLE OF CONTENTS</strong>
                </button>
</div>
    <div class="container" style="padding-top:0;border:3px solid black;margin-bottom:50px;">
        
            
            <div id="ToC" class="collapse"style="position:fixed;background-color:white;z-index:10;bottom:50px;">
            

                
            <?php
                function OpenCon()
                {
                $dbhost = "localhost";
                $dbuser = "root";
                $dbpass = "";
                $db = "MetaBeta";
                $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
                return $conn;
                }
                $conn = OpenCon();
                $sqlDel = "SELECT id, ObjectiveTitle FROM Strategic_Goals";
                $Result1 = $conn->query($sqlDel);
                $count = 1;
                echo '<div  style="overflow-y:scroll; overflow-x:hidden;padding:0;padding-right:25px;height:350px;">';
                while($row = $Result1->fetch_assoc()) 
                {
                    $Reqcount = 1;
                    echo '
                    
                        <div style="float:left;">'.$count.') </div>
                        <div style="padding-left:23px;">
                        <a href="http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Obj'.$row["id"].'" >'.$row["ObjectiveTitle"].'</a></div>';
                        $sqlDel2 = "SELECT * FROM Scope_Requirements WHERE StrategyID = ".$row["id"];
                        $Result2 = $conn->query($sqlDel2);
                        
                            while($row2 = $Result2->fetch_assoc()) 
                            {
                                
                                echo '
                                <div style="float:left;padding-left:25px;">'.$count.'.'.$Reqcount.')</div>
                                <div style="padding-left:60px;">
                                    <a href="http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Req'.$row2["id"].'" >'.$row2["RequirementTitle"].'</a>
                                </div>
                                ';
                               
                                $DevCount = 1;
                                $sqlDel3 = "SELECT * FROM Structure_Deliverables WHERE RequirementID = ".$row2["id"];
                                $Result3 = $conn->query($sqlDel3);
                                    
                                while($row3 = $Result3->fetch_assoc()) 
                                    {
                                        echo '
                                            <div style="float:left;padding-left:60px;">'.$count.'.'.$Reqcount.'.'.$DevCount.')</div>
                                            <div style="padding-left:108px;">
                                                <a  href="http://localhost/MetaBetaTest/GenerateGoalReqDeliverable.php#Del'.$row3["id"].'" >'.$row3["DeliverableTitle"].'</a>
                                            </div>
                                        ';
                                        $DevCount = $DevCount + 1;
                                    }
                                    $Reqcount = $Reqcount + 1;
                                }
                    
                    $count = $count + 1;
                
                }
                echo '</div>';

    ?>
                

            </div>
    
        <?php
            $conn = OpenCon();
            $sqlDel = "SELECT * FROM Strategic_Goals";
            $Result1 = $conn->query($sqlDel);
            $count = 1;
            echo '<div class="main" style="position:relative;">';
            while($row = $Result1->fetch_assoc()) 
            {
                $Reqcount = 1;
                echo '
                <ol>
                    <li>
                    <h1 style="padding-left:10px;width:100%;" id="Obj'.$row["id"].'" >'.$count.') '.$row["ObjectiveTitle"].'</h1>
                    <h4 style="padding-left:75px;width:100%;">'.$row["ObjectiveQuestion"].'</h4>
                    <p style="padding-left:20px;border-left:2px solid black;margin-left:79px;font-size:18px;padding-right:100px;">'.nl2br(str_replace("  ", "&nbsp;", $row["ObjectiveDescription"])).'</p>
                    ';
                    $sqlDel2 = "SELECT * FROM Scope_Requirements WHERE StrategyID = ".$row["id"];
                    $Result2 = $conn->query($sqlDel2);
                    
                        while($row2 = $Result2->fetch_assoc()) 
                        {
                            echo '
                            <ol>
                                <li>
                                    <h2 style="width:100%;padding-left:75px;"  id="Req'.$row2["id"].'" >'.$count.'.'.$Reqcount.') '.$row2["RequirementTitle"].'</h2>
                                    <h4 style="padding-left:145px;width:100%;">'.$row2["RequirementType"].'</h4>
                                    <p style="padding-left:20px;border-left:2px solid black;margin-left:150px;font-size:18px;padding-right:100px;">'.nl2br(str_replace("  ", "&nbsp;", $row2["RequirementDescription"])).'</p>
                            ';
                            
                            $DevCount = 1;
                            $sqlDel3 = "SELECT * FROM Structure_Deliverables WHERE RequirementID = ".$row2["id"];
                            $Result3 = $conn->query($sqlDel3);
                                
                            while($row3 = $Result3->fetch_assoc()) 
                                {
                                    echo '
                                            <ol>
                                                <li>
                                                    <h3 style="width:100%;padding-left:150px;padding-right:100px;"  id="Del'.$row3["id"].'" >'.$count.'.'.$Reqcount.'.'.$DevCount.') '.$row3["DeliverableTitle"].'</h3>
                                                    <h4 style="padding-left:222px;width:100%;padding-right:100px;">'.$row3["DeliverableType"].'</h4>
                                                    <p style="padding-left:20px;border-left:2px solid black;margin-left:222px;font-size:18px;padding-right:100px;">'.nl2br(str_replace("  ", "&nbsp;", str_replace("\t", "&nbsp&nbsp&nbsp&nbsp;",$row3["DeliverableCoreIdea"]))).'<br><br>'. nl2br(str_replace("  ", "&nbsp;", $row3["DeliverableDeliveryMethod"])).'</p>
                                
                                            ';
                                    $DevCount = $DevCount + 1;
                                }
                                echo '</li>
                            </ol>';
                        
                                $Reqcount = $Reqcount + 1;
                            }

                            echo '</li>
                            </ol>';
                $count = $count + 1;
              
            }
            echo '</div>';?>

    </div>
</body>
</html>