<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>|Object|Requirements|Deliverables|</title>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  
</head>
<script>
    $('#contact-form').on( 'change keydown keyup paste cut', 'textarea', function () {  
  $(this).height(0).height(this.scrollHeight+2);
  if ($(this).height() >= 300) {
    $('textarea#message').css("overflow", "auto");
  }
  else {
    $('textarea#message').css("overflow", "hidden");
  }
}).find('textarea#message').change();
   
  </script>
<style>
   #swapView{font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:20px;padding-bottom:20px;width:100%;text-decoration:underline;}
   #swapView:hover {font-size:22px;background-color:white !important;color:#003faa !important;text-align:center;padding-top:20px;padding-bottom:20px;width:100%;}
   #selecta:hover{background-color:black;color:white;}
   .active {background-color:black;color:white;}
   #selecta{padding-left:15px;padding-right:15px;padding-bottom:6px;padding-top:6px;width:100%;text-align:left;font-size:20px;}
   textarea {height: 100%; }
</style>
<body >
 <?php
                function OpenCon()
                {
                $dbhost = "localhost";
                $dbuser = "root";
                $dbpass = "";
                $db = "MetaBeta";
                $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
                return $conn;
                }
                $conn = OpenCon();
                
echo '
<div class="container" style="max-width:80% !important;">

<div class="row">';
                    if(empty($_GET["activeObjective"]) & empty($_GET["activeRequirement"]) & empty($_GET["activeDeliverable"]) )
                    {
                                    echo '<a id="swapView" style="font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:14px;padding-bottom:14px;width:100%;" type="button" class="button" href="GenerateObjReqDel.1.php">Switch to Column View</a>';
                    }
                    if(!empty($_GET["activeRequirement"]) & empty($_GET["activeDeliverable"]) )
                        {
                                
                                    echo '<a id="swapView" style="font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:14px;padding-bottom:14px;width:100%;" type="button" class="button" href="GenerateObjReqDel.1.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$_GET["activeRequirement"].'">Switch to Vertical View</a>';
                                    
                        }

                    if(!empty($_GET["activeObjective"]) & empty($_GET["activeRequirement"]) )
                        {
                                
                            echo '<a id="swapView" style="font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:14px;padding-bottom:14px;width:100%;" type="button" class="button" href="GenerateObjReqDel.1.php?activeObjective='.$_GET["activeObjective"].'">Switch to Vertical View</a>'; 
                        }   
                    if(!empty($_GET["activeDeliverable"]))
                        {
                                
                            echo '<a id="swapView" style="font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:14px;padding-bottom:14px;width:100%;"  type="button" class="button" href="GenerateObjReqDel.1.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$_GET["activeRequirement"].'&activeDeliverable='.$_GET["activeDeliverable"].'">Switch to Vertical View</a>';
                        }   

echo '</div>


    <div class="row">
        <div class="col col-sm-4" style="border:solid 2px black;background-color:#a3c09a;">
            <h2>Select Objective:</h2>
        </div>
        <div class="col col-sm-4" style="border:solid 2px black;background-color:#e8dd67;">
            <h2>Select Requirement:</h2>
        </div>
        <div class="col col-sm-4" style="border:solid 2px black;background-color:#d98484;">
            <h2>Select Deliverable:</h2>
        </div>
    </div>

    <div class="row">
        <div class="col col-sm-4" style="border:solid 2px black;padding:0">
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:275px;">';
            
                $sqlDel = "SELECT * FROM Strategic_Goals";
                $Result1 = $conn->query($sqlDel);
                while($row = $Result1->fetch_assoc()) 
                    {
                        if(!empty($_GET["activeObjective"]) )
                        {
                            if($_GET["activeObjective"] == $row["id"])
                                {
                                echo '<div style="width:100%;"><a class="active"  type="button" id="selecta" style="width:100%;color:#a3c09a;"  href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='. $row["id"].'">'.$row["ObjectiveTitle"].'</a></div>';
                                }
                            else
                                {
                                    echo '<div style="width:100%;"><a type="button" id="selecta" style="width:100%;"  href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='. $row["id"].'">'.$row["ObjectiveTitle"].'</a></div>';
                                }  
                        }else{
                            echo '<div style="width:100%;"><a id="selecta" type="button" style="width:100%;" href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='. $row["id"].'">'.$row["ObjectiveTitle"].'</a></div>';
                        }    

                    }
              
      echo '</div>
        </div>
        <div class="col col-sm-4" style="border:solid 2px black;padding:0">
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:275px;">';
            if(!empty($_GET["activeObjective"]))
            {
            $sqlDel2 = "SELECT * FROM Scope_Requirements WHERE StrategyID = ".$_GET["activeObjective"];
            $Result2 = $conn->query($sqlDel2);
            while($row2 = $Result2->fetch_assoc()) 
                {
                    if(!empty($_GET["activeRequirement"]) )
                    {
                        if($_GET["activeRequirement"] == $row2["id"])
                            {
                            echo '<div style="width:100%;"><a class="active"  type="button" id="selecta" style="width:100%;color:#e8dd67;" href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$row2["id"].'">'.$row2["RequirementTitle"].'</a></div>';
                            }
                        else
                            {
                                echo '<div style="width:100%;"><a type="button" id="selecta" style="width:100%;" href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$row2["id"].'">'.$row2["RequirementTitle"].'</a></div>';
                            }  
                    }else{
                    echo '<div style="width:100%;"><a type="button" id="selecta" style="width:100%;" href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$row2["id"].'">'.$row2["RequirementTitle"].'</a></div>';
                    }   
                }
            }

      echo '</div>
        </div>
        <div class="col col-sm-4" style="border:solid 2px black;padding:0">
            <div  style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:275px;">';
            
            if(!empty($_GET["activeRequirement"]))
            {
            $sqlDel3 = "SELECT * FROM Structure_Deliverables WHERE RequirementID = ".$_GET["activeRequirement"];
            $Result3 = $conn->query($sqlDel3);
            while($row3 = $Result3->fetch_assoc()) 
                {
                    if(!empty($_GET["activeDeliverable"]) )
                    {
                        if($_GET["activeDeliverable"] == $row3["id"])
                            {
                            echo '<div style="width:100%;"><a class="active"  type="button" id="selecta" style="width:100%;color:#d98484"  href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$_GET["activeRequirement"].'&activeDeliverable='.$row3["id"].'">'.$row3["DeliverableTitle"].'</a></div>';
                            }
                        else
                            {
                                echo '<div style="width:100%;"><a type="button" id="selecta" style="width:100%;"  href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$_GET["activeRequirement"].'&activeDeliverable='.$row3["id"].'">'.$row3["DeliverableTitle"].'</a></div>';
                            }  
                    }else{
                        echo '<div style="width:100%;"><a id="selecta" type="button" style="width:100%;" href="http://localhost/MetaBetaTest/GenerateObjReqDel.php?activeObjective='.$_GET["activeObjective"].'&activeRequirement='.$_GET["activeRequirement"].'&activeDeliverable='.$row3["id"].'">'.$row3["DeliverableTitle"].'</a></div>';                    
                    }       
                }   
            } 
        echo '</div>
        </div>
    </div>

    <div class="row">
        <div class="col col-sm-4" style="border:solid 2px black;background-color:#a3c09a;min-height:56px;">';
            if(!empty($_GET["activeObjective"]))
            {
            $sqlDel3 = "SELECT * FROM Strategic_Goals WHERE id = ".$_GET["activeObjective"];
            $Result3 = $conn->query($sqlDel3);
            while($row3 = $Result3->fetch_assoc()) 
                {
                    echo '<h5 style="font-size:27px;">'.$row3["ObjectiveTitle"].'</h5>';

                }   
            } 
  echo '</div>
        <div class="col col-sm-4" style="border:solid 2px black;background-color:#e8dd67;">';
        if(!empty($_GET["activeRequirement"]))
        {
        $sqlDel3 = "SELECT RequirementTitle FROM Scope_Requirements WHERE id = ".$_GET["activeRequirement"];
        $Result3 = $conn->query($sqlDel3);
        while($row3 = $Result3->fetch_assoc()) 
            {
                echo '<h5 style="font-size:27px;">'.$row3["RequirementTitle"].'</h5>';

            }   
        } 
  echo '</div>
        <div class="col col-sm-4" style="border:solid 2px black;background-color:#d98484">';
        if(!empty($_GET["activeDeliverable"]))
        {
        $sqlDel3 = "SELECT DeliverableTitle FROM structure_Deliverables WHERE id = ".$_GET["activeDeliverable"];
        $Result3 = $conn->query($sqlDel3);
        while($row3 = $Result3->fetch_assoc()) 
            {
                echo '<h5 style="font-size:27px;">'.$row3["DeliverableTitle"].'</h5>';

            }   
        } 
  echo '</div>
    </div>

    <div class="row">
        <div class="col col-sm-4" style="border:solid 2px black;;min-height:1500px;padding:0;">';
            if(!empty($_GET["activeObjective"]))
            {
            $sqlDel3 = "SELECT * FROM Strategic_Goals WHERE id = ".$_GET["activeObjective"];
            $Result3 = $conn->query($sqlDel3);
            while($row3 = $Result3->fetch_assoc()) 
                {
                    echo '<textarea  style="width:100%;padding-left:20px;padding-right:25px;margin:0;padding-bottom:0;">'. $row3["ObjectiveDescription"].'</textarea>';
                }   
            } 
  echo '</div>
        <div class="col col-sm-4" style="border:solid 2px black;padding:0;">';
        if(!empty($_GET["activeRequirement"]))
        {
        $sqlDel3 = "SELECT * FROM Scope_Requirements WHERE id = ".$_GET["activeRequirement"];
        $Result3 = $conn->query($sqlDel3);
        while($row3 = $Result3->fetch_assoc()) 
            {
                echo '<textarea style="width:100%;padding-left:20px;padding-right:25px;margin:0;padding-bottom:0;">'. $row3["RequirementDescription"].'</textarea>';

            }   
        } 
  echo '</div>
        <div class="col col-sm-4" style="border:solid 2px black;padding:0;">';
        if(!empty($_GET["activeDeliverable"]))
        {
        $sqlDel3 = "SELECT * FROM structure_Deliverables WHERE id = ".$_GET["activeDeliverable"];
        $Result3 = $conn->query($sqlDel3);
        while($row3 = $Result3->fetch_assoc()) 
            {
                echo '<textarea style="width:100%;padding-left:20px;padding-right:25px;margin:0;padding-bottom:0;">'. $row3["DeliverableCoreIdea"].'

'. $row3["DeliverableDeliveryMethod"].'</textarea>';
            }   
        } 
  echo '</div>
    </div>
</div>';
?>
</body>
</html>