<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Title of the document</title>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</head>

<body>

    <div class="container" style="max-width: 2040px;">
            <?php
            function OpenCon()
            {
            $dbhost = "localhost";
            $dbuser = "root";
            $dbpass = "";
            $db = "MetaBeta";
            
            
            $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
            
            return $conn;
            }
            $conn = OpenCon();
            $sqlDel = "SELECT DeliverableGlobalNavTagList FROM Structure_Deliverables WHERE DeliverableGlobalNavTagList IS NOT NULL ";
            $Result1 = $conn->query($sqlDel);
            
            $CountDiv = 2;
            while($row = $Result1->fetch_assoc()) 
            {
                $count1 = 1;
                if($CountDiv %2 == 0)
                {
                    
                echo '
                <div class = "row">
                <div class="col-sm-6" style="margin:0;">
                    <h3>'.$row["DeliverableGlobalNavTagList"].'</h3>
                <div style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;">
                ';
                
                $GlobalNav = $row["DeliverableGlobalNavTagList"];
                $sqlDel2 = "SELECT id, DeliverableLocalNavTagList FROM Structure_Deliverables WHERE DeliverableLocalNavTagList IS NOT NULL AND DeliverableGlobalNavTag ='".$row["DeliverableGlobalNavTagList"]."' ";
                $Result2 = $conn->query($sqlDel2);
                while($row2 = $Result2->fetch_assoc()) 
                {
                    
                    echo '<button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#29A5FF;" type="button" data-toggle="collapse" data-target="#LocalNavTag'. $row2["id"] . '">
                                <strong>'.$count1.'. ) '. $row2["DeliverableLocalNavTagList"].'</strong>
                          </button> 

                          <div class="collapse" id="LocalNavTag'. $row2["id"] . '">';
                          $count1 += 1;
                                    $sqlDel3 = "SELECT * FROM Structure_Deliverables where DeliverableLocalNavTag = '". $row2["DeliverableLocalNavTagList"] ."' AND DeliverableType IS NOT NULL";
                                    $Result3 = $conn->query($sqlDel3);
                                    while($row3 = $Result3->fetch_assoc()) 
                                    {
                                        
                                        echo '                           
                                            <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#99DFFF;" type="button" data-toggle="modal" data-target="#DeliverableModal'. $row3["id"] . '">
                                                <strong>'. $row3["DeliverableTitle"]. '</strong>
                                            </button>
                                        <div class="modal" id="DeliverableModal'. $row3["id"] . '">
                                            <div style="max-width:1200px !important;"class="modal-dialog">
                                                <div class="modal-content">
                                                
                                                    <div class="modal-header" style="background-color:#679e97;padding-left:0;">
                                                        <h3 style="margin:0;padding-left:0;">'. $row3["DeliverableType"] . ' Deliverable:</h3>
                                                    </div>
                                                    <!-- Modal body -->
                                                    <div class="modal-body" style="padding:0;">
                                                        
                                                        <button style="padding-left:60px;white-space: nowrap;font-size:18px;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="collapse" data-target="#LocalNavDeliverablesCollapse'. $row3["id"] . '">
                                                                <strong>'. $row3["DeliverableTitle"].'</strong>
                                                        </button> 
                                                        <div class="collapse" id="LocalNavDeliverablesCollapse'. $row3["id"] . '" style="padding-left:60px;">';
                                                            $sqlDel4 = "SELECT *  FROM Structure_Deliverables where id = '". $row3["id"] ."'";
                                                            $Result4 = $conn->query($sqlDel4);
                                                            while($row4 = $Result4->fetch_assoc()) 
                                                            {
                                                                echo '<label style="margin:0;font-size:16px;color:black;"><strong> Core Idea:</strong></label>
                                                                <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["DeliverableCoreIdea"].$row4["DeliverableDeliveryMethod"].'</textarea>';
                                                            

                                                  echo '</div>
                                                  <h3 style="background-color:#b6a9b0;margin:0;">Requirement:</h3>
                                                        <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#b6a9b0;" type="button" data-toggle="collapse" data-target="#DeliverablesRequirementCollapse'. $row4["id"] . '">
                                                            <strong>'. $row4["RequirementTitle"].'</strong>
                                                        </button> 
                                                        <div class="collapse" id="DeliverablesRequirementCollapse'. $row4["id"] . '" style="padding-left:60px;">
                                                            <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["RequirementType"] . '</strong></label>
                                                            <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["RequirementDescription"].'</textarea>
                                                        </div>
                                                    <h3 style="background-color:#8d9390;margin:0;">Objective:</h3>                
                                                        <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#8d9390;" type="button" data-toggle="collapse" data-target="#DeliverablesObjective'. $row4["id"] . '">
                                                            <strong>'. $row4["ObjectiveTitle"].'</strong>
                                                        </button> 
                                                        <div class="collapse" id="DeliverablesObjective'. $row4["id"] . '" style="padding-left:60px;">
                                                            <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveType"] . '</strong></label><br>
                                                            <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveQuestion"] . '</strong></label>
                                                            <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["ObjectiveDescription"].'</textarea>
                                                        </div>
                                                        ';
                                                            }
                                                
                                            
                                              echo '</div>
                                                </div>
                                            </div>
                                        </div>';
                                    
                                    }
                  echo ' </div>';
                }
                $sqlDel3 = "SELECT * FROM Structure_Deliverables where DeliverableLocalNavTag = '". $row2["DeliverableLocalNavTagList"] ."' AND DeliverableType IS NOT NULL";
                $Result3 = $conn->query($sqlDel3);
                while($row3 = $Result3->fetch_assoc()) 
                {
                    echo '                           
                        <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#99DFFF;" type="button" data-toggle="modal" data-target="#DeliverableModal'. $row3["id"] . '">
                            <strong>'. $row3["DeliverableTitle"]. '</strong>
                        </button>
                    <div class="modal" id="DeliverableModal'. $row3["id"] . '">
                        <div style="max-width:1200px !important;"class="modal-dialog">
                            <div class="modal-content">
                            
                                <div class="modal-header" style="background-color:#679e97;padding-left:0;">
                                    <h3 style="margin:0;padding-left:0;">'. $row3["DeliverableType"] . ' Deliverable:</h3>
                                </div>
                                <!-- Modal body -->
                                <div class="modal-body" style="padding:0;">
                                    
                                    <button style="padding-left:60px;white-space: nowrap;font-size:18px;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="collapse" data-target="#LocalNavDeliverablesCollapse'. $row3["id"] . '">
                                            <strong>'. $row3["DeliverableTitle"].'</strong>
                                    </button> 
                                    <div class="collapse" id="LocalNavDeliverablesCollapse'. $row3["id"] . '" style="padding-left:60px;">';
                                        $sqlDel4 = "SELECT *  FROM Structure_Deliverables where id = '". $row3["id"] ."'";
                                        $Result4 = $conn->query($sqlDel4);
                                        while($row4 = $Result4->fetch_assoc()) 
                                        {
                                            echo '<label style="margin:0;font-size:16px;color:black;"><strong> Core Idea:</strong></label>
                                            <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["DeliverableCoreIdea"].$row4["DeliverableDeliveryMethod"].'</textarea>';
                                        

                              echo '</div>
                              <h3 style="background-color:#b6a9b0;margin:0;">Requirement:</h3>
                                    <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#b6a9b0;" type="button" data-toggle="collapse" data-target="#DeliverablesRequirementCollapse'. $row4["id"] . '">
                                        <strong>'. $row4["RequirementTitle"].'</strong>
                                    </button> 
                                    <div class="collapse" id="DeliverablesRequirementCollapse'. $row4["id"] . '" style="padding-left:60px;">
                                        <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["RequirementType"] . '</strong></label>
                                        <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["RequirementDescription"].'</textarea>
                                    </div>
                                <h3 style="background-color:#8d9390;margin:0;">Objective:</h3>                
                                    <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#8d9390;" type="button" data-toggle="collapse" data-target="#DeliverablesObjective'. $row4["id"] . '">
                                        <strong>'. $row4["ObjectiveTitle"].'</strong>
                                    </button> 
                                    <div class="collapse" id="DeliverablesObjective'. $row4["id"] . '" style="padding-left:60px;">
                                        <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveType"] . '</strong></label><br>
                                        <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveQuestion"] . '</strong></label>
                                        <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["ObjectiveDescription"].'</textarea>
                                    </div>
                                    ';
                                        }
                            
                        
                          echo '</div>
                            </div>
                        </div>
                    </div>';
                
                }
                $sqlDel3 = "SELECT * FROM Structure_Deliverables where DeliverableLocalNavTag IS NULL AND DeliverableGlobalNavTag = '$GlobalNav' AND DeliverableType IS NOT NULL";
                                        $Result3 = $conn->query($sqlDel3);
                                        while($row3 = $Result3->fetch_assoc()) 
                                        {
                                            echo '                           
                                                <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="modal" data-target="#DeliverableModal'. $row3["id"] . '">
                                                    <strong>'.$count1 .'. ) ' . $row3["DeliverableTitle"]. '</strong>
                                                </button>';
                                                $count1 += 1;
                                                echo ' 
                                            <div class="modal" id="DeliverableModal'. $row3["id"] . '">
                                                <div style="max-width:1200px !important;"class="modal-dialog">
                                                    <div class="modal-content">
                                                    
                                                        <div class="modal-header" style="background-color:#679e97;padding-left:0;">
                                                            <h3 style="margin:0;padding-left:0;">'. $row3["DeliverableType"] . ' Deliverable:</h3>
                                                        </div>
                                                        <!-- Modal body -->
                                                        <div class="modal-body" style="padding:0;">
                                                            
                                                            <button style="padding-left:60px;white-space: nowrap;font-size:18px;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="collapse" data-target="#LocalNavDeliverablesCollapse'. $row3["id"] . '">
                                                                    <strong>'. $row3["DeliverableTitle"].'</strong>
                                                            </button> 
                                                            <div class="collapse" id="LocalNavDeliverablesCollapse'. $row3["id"] . '" style="padding-left:60px;">';
                                                                $sqlDel4 = "SELECT *  FROM Structure_Deliverables where id = '". $row3["id"] ."'";
                                                                $Result4 = $conn->query($sqlDel4);
                                                                while($row4 = $Result4->fetch_assoc()) 
                                                                {
                                                                    echo '<label style="margin:0;font-size:16px;color:black;"><strong> Core Idea:</strong></label>
                                                                    <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["DeliverableCoreIdea"].$row4["DeliverableDeliveryMethod"].'</textarea>';
                                                                
    
                                                      echo '</div>
                                                      <h3 style="background-color:#b6a9b0;margin:0;">Requirement:</h3>
                                                            <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#b6a9b0;" type="button" data-toggle="collapse" data-target="#DeliverablesRequirementCollapse'. $row4["id"] . '">
                                                                <strong>'. $row4["RequirementTitle"].'</strong>
                                                            </button> 
                                                            <div class="collapse" id="DeliverablesRequirementCollapse'. $row4["id"] . '" style="padding-left:60px;">
                                                                <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["RequirementType"] . '</strong></label>
                                                                <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["RequirementDescription"].'</textarea>
                                                            </div>
                                                        <h3 style="background-color:#8d9390;margin:0;">Objective:</h3>                
                                                            <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#8d9390;" type="button" data-toggle="collapse" data-target="#DeliverablesObjective'. $row4["id"] . '">
                                                                <strong>'. $row4["ObjectiveTitle"].'</strong>
                                                            </button> 
                                                            <div class="collapse" id="DeliverablesObjective'. $row4["id"] . '" style="padding-left:60px;">
                                                                <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveType"] . '</strong></label><br>
                                                                <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveQuestion"] . '</strong></label>
                                                                <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["ObjectiveDescription"].'</textarea>
                                                            </div>
                                                            ';
                                                                }
                                                    
                                                
                                                  echo '</div>
                                                    </div>
                                                </div>
                                            </div>';
                                        
                                        }                   
                echo '
                        
                    </div>
                </div>

                ';
               
                $CountDiv = 1;
                }
                else
                {
                    echo '
                    
                    <div class="col-sm-6" style="margin:0;">
                        <h3>'.$row["DeliverableGlobalNavTagList"].'</h3>
                        <div style="overflow-y:scroll; overflow-x:hidden;background-color:#cccccc;padding:0 !important;height:250px;">
                    ';
                    $GlobalNav = $row["DeliverableGlobalNavTagList"];
                    $sqlDel2 = "SELECT id, DeliverableLocalNavTagList FROM Structure_Deliverables WHERE DeliverableLocalNavTagList IS NOT NULL AND DeliverableGlobalNavTag ='".$row["DeliverableGlobalNavTagList"]."' ";
                    $Result2 = $conn->query($sqlDel2);
                    while($row2 = $Result2->fetch_assoc()) 
                    {
                        echo '<button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#29A5FF;" type="button" data-toggle="collapse" data-target="#LocalNavTag'. $row2["id"] . '">
                                    <strong>'.$count1.'. ) '. $row2["DeliverableLocalNavTagList"].'</strong>
                              </button> 
                              <div class="collapse" id="LocalNavTag'. $row2["id"] . '">';
                              $count1 += 1;
                                        $sqlDel3 = "SELECT * FROM Structure_Deliverables where DeliverableLocalNavTag = '". $row2["DeliverableLocalNavTagList"] ."' AND DeliverableType IS NOT NULL";
                                        $Result3 = $conn->query($sqlDel3);
                                        while($row3 = $Result3->fetch_assoc()) 
                                        {
                                            echo '                           
                                                <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#99DFFF;" type="button" data-toggle="modal" data-target="#DeliverableModal'. $row3["id"] . '">
                                                    <strong>'. $row3["DeliverableTitle"]. '</strong>
                                                </button>
                                            <div class="modal" id="DeliverableModal'. $row3["id"] . '">
                                                <div style="max-width:1200px !important;"class="modal-dialog">
                                                    <div class="modal-content">
                                                    
                                                        <div class="modal-header" style="background-color:#679e97;padding-left:0;">
                                                            <h3 style="margin:0;padding-left:0;">'. $row3["DeliverableType"] . ' Deliverable:</h3>
                                                        </div>
                                                        <!-- Modal body -->
                                                        <div class="modal-body" style="padding:0;">
                                                            
                                                            <button style="padding-left:60px;white-space: nowrap;font-size:18px;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="collapse" data-target="#LocalNavDeliverablesCollapse'. $row3["id"] . '">
                                                                    <strong>'. $row3["DeliverableTitle"].'</strong>
                                                            </button> 
                                                            <div class="collapse" id="LocalNavDeliverablesCollapse'. $row3["id"] . '" style="padding-left:60px;">';
                                                                $sqlDel4 = "SELECT *  FROM Structure_Deliverables where id = '". $row3["id"] ."'";
                                                                $Result4 = $conn->query($sqlDel4);
                                                                while($row4 = $Result4->fetch_assoc()) 
                                                                {
                                                                    echo '<label style="margin:0;font-size:16px;color:black;"><strong> Core Idea:</strong></label>
                                                                    <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["DeliverableCoreIdea"].$row4["DeliverableDeliveryMethod"].'</textarea>';
                                                                
    
                                                      echo '</div>
                                                      <h3 style="background-color:#b6a9b0;margin:0;">Requirement:</h3>
                                                            <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#b6a9b0;" type="button" data-toggle="collapse" data-target="#DeliverablesRequirementCollapse'. $row4["id"] . '">
                                                                <strong>'. $row4["RequirementTitle"].'</strong>
                                                            </button> 
                                                            <div class="collapse" id="DeliverablesRequirementCollapse'. $row4["id"] . '" style="padding-left:60px;">
                                                                <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["RequirementType"] . '</strong></label>
                                                                <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["RequirementDescription"].'</textarea>
                                                            </div>
                                                        <h3 style="background-color:#8d9390;margin:0;">Objective:</h3>                
                                                            <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#8d9390;" type="button" data-toggle="collapse" data-target="#DeliverablesObjective'. $row4["id"] . '">
                                                                <strong>'. $row4["ObjectiveTitle"].'</strong>
                                                            </button> 
                                                            <div class="collapse" id="DeliverablesObjective'. $row4["id"] . '" style="padding-left:60px;">
                                                                <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveType"] . '</strong></label><br>
                                                                <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveQuestion"] . '</strong></label>
                                                                <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["ObjectiveDescription"].'</textarea>
                                                            </div>
                                                            ';
                                                                }
                                                    
                                                
                                                  echo '</div>
                                                    </div>
                                                </div>
                                            </div>';
                                        
                                        }
                                        
                      echo ' </div>';
                    }
                    $sqlDel3 = "SELECT * FROM Structure_Deliverables where DeliverableLocalNavTag IS NULL AND DeliverableGlobalNavTag = '$GlobalNav' AND DeliverableType IS NOT NULL";
                    $Result3 = $conn->query($sqlDel3);
                    while($row3 = $Result3->fetch_assoc()) 
                    {
                        echo   '                    
                            <button style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="modal" data-target="#DeliverableModal'. $row3["id"] . '">
                                <strong>'.$count.'. ) '. $row2["DeliverableLocalNavTagList"].'</strong>
                            </button>';
                            $count1 += 1;
                            echo ' <div class="modal" id="DeliverableModal'. $row3["id"] . '">
                            <div style="max-width:1200px !important;"class="modal-dialog">
                                <div class="modal-content">
                                
                                    <div class="modal-header" style="background-color:#679e97;padding-left:0;">
                                        <h3 style="margin:0;padding-left:0;">'. $row3["DeliverableType"] . ' Deliverable:</h3>
                                    </div>
                                    <!-- Modal body -->
                                    <div class="modal-body" style="padding:0;">
                                        
                                        <button style="padding-left:60px;white-space: nowrap;font-size:18px;overflow: hidden;text-overflow: ellipsis;text-align:left;width:100%;border:solid black 2px;background-color:#679e97;" type="button" data-toggle="collapse" data-target="#LocalNavDeliverablesCollapse'. $row3["id"] . '">
                                                <strong>'. $row3["DeliverableTitle"].'</strong>
                                        </button> 
                                        <div class="collapse" id="LocalNavDeliverablesCollapse'. $row3["id"] . '" style="padding-left:60px;">';
                                            $sqlDel4 = "SELECT *  FROM Structure_Deliverables where id = '". $row3["id"] ."'";
                                            $Result4 = $conn->query($sqlDel4);
                                            while($row4 = $Result4->fetch_assoc()) 
                                            {
                                                echo '<label style="margin:0;font-size:16px;color:black;"><strong> Core Idea:</strong></label>
                                                <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["DeliverableCoreIdea"].$row4["DeliverableDeliveryMethod"].'</textarea>';
                                            

                                  echo '</div>
                                  <h3 style="background-color:#b6a9b0;margin:0;">Requirement:</h3>
                                        <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#b6a9b0;" type="button" data-toggle="collapse" data-target="#DeliverablesRequirementCollapse'. $row4["id"] . '">
                                            <strong>'. $row4["RequirementTitle"].'</strong>
                                        </button> 
                                        <div class="collapse" id="DeliverablesRequirementCollapse'. $row4["id"] . '" style="padding-left:60px;">
                                            <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["RequirementType"] . '</strong></label>
                                            <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["RequirementDescription"].'</textarea>
                                        </div>
                                    <h3 style="background-color:#8d9390;margin:0;">Objective:</h3>                
                                        <button style="padding-left:60px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;font-size:18px;text-align:left;width:100%;border:solid black 2px;background-color:#8d9390;" type="button" data-toggle="collapse" data-target="#DeliverablesObjective'. $row4["id"] . '">
                                            <strong>'. $row4["ObjectiveTitle"].'</strong>
                                        </button> 
                                        <div class="collapse" id="DeliverablesObjective'. $row4["id"] . '" style="padding-left:60px;">
                                            <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveType"] . '</strong></label><br>
                                            <label style="margin:0;font-size:16px;color:black;"><strong>'. $row4["ObjectiveQuestion"] . '</strong></label>
                                            <textarea   rows="5" name="EditDescription" style="resize:vertical;width:100%;height:750px;" autocomplete="off">'. $row4["ObjectiveDescription"].'</textarea>
                                        </div>
                                        ';
                                            }
                                
                            
                              echo '</div>
                                </div>
                            </div>
                        </div>';
                    
                    }                    
                    echo '
                            
                        </div>
                    </div>
                </div>
                    ';
                $CountDiv = 2;
                }
            }
            ?>
        </div>
    </div>
</body>
</html>