<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>|Object|Requirements|Deliverables|</title>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<style>
   #swapView{font-size:22px;background-color:#003faa;color:white;text-align:center;padding-top:20px;padding-bottom:20px;width:100%;text-decoration:underline;}
   #swapView:hover {font-size:22px;background-color:white !important;color:#003faa !important;text-align:center;padding-top:20px;padding-bottom:20px;width:100%;}
   #selecta:hover{background-color:orange;color:white;}
   #selecta{padding-left:15px;padding-right:15px;padding-bottom:6px;padding-top:6px;width:100%;text-align:left;font-size:20px;}
   .hide{display:none;}
   .Show{display:block;}
</style>
</head>

<body style="height:2000px;">
<script>
function OBJHider(id)
    {
        var testarray = document.getElementsByClassName("ObjDesc");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('Show');
            testarray[i].classList.remove('hide'); 
            testarray[i].classList.add('hide');
        }
        var testarray2 = document.getElementsByClassName("ObjHeader");
        for(var i = 0; i < testarray2.length; i++)
        {
            testarray2[i].classList.remove('Show');
            testarray2[i].classList.remove('hide');
            testarray2[i].classList.add('hide');
        }
        var testarray3 = document.getElementsByClassName("ReqSel");
        for(var i = 0; i < testarray3.length; i++)
        {
            testarray3[i].classList.remove('Show');
            testarray3[i].classList.remove('hide');
            testarray3[i].classList.add('hide');
        }
        var testarray3 = document.getElementsByClassName("ReqSel"+ id);
        for(var i = 0; i < testarray3.length; i++)
        {
            testarray3[i].classList.remove('Show');
            testarray3[i].classList.remove('hide');
            testarray3[i].classList.add('Show');
        }
        var testarray = document.getElementsByClassName("ReqDesc");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('Show');
            testarray[i].classList.remove('hide'); 
            testarray[i].classList.add('hide');
        }
        var testarray2 = document.getElementsByClassName("ReqHeader");
        for(var i = 0; i < testarray2.length; i++)
        {
            testarray2[i].classList.remove('Show');
            testarray2[i].classList.remove('hide');
            testarray2[i].classList.add('hide');
        }
        var testarray3 = document.getElementsByClassName("DelSel");
        for(var i = 0; i < testarray3.length; i++)
        {
            testarray3[i].classList.remove('Show');
            testarray3[i].classList.remove('hide');
            testarray3[i].classList.add('hide');
        }
        var element =  document.getElementById("ReqSel" + id);
            if (typeof(element) != 'undefined' && element != null)
            {
            document.getElementById("ReqSel" + id).classList.add('Show');
            document.getElementById("ReqSel" + id).classList.remove('hide');
            }
            var testarray = document.getElementsByClassName("DelDesc");
        for(var i = 0; i < testarray.length; i++)
        {
            testarray[i].classList.remove('Show');
            testarray[i].classList.remove('hide'); 
            testarray[i].classList.add('hide');
        }
        var testarray2 = document.getElementsByClassName("DelHeader");
        for(var i = 0; i < testarray2.length; i++)
        {
            testarray2[i].classList.remove('Show');
            testarray2[i].classList.remove('hide');
            testarray2[i].classList.add('hide');
        }

        document.getElementById("HeaderOBJ" + id).classList.add('Show');
        document.getElementById("HeaderOBJ" + id).classList.remove('hide');
        document.getElementById("HeaderDesc" + id).classList.add('Show');
        document.getElementById("HeaderDesc" + id).classList.remove('hide');   

    }     
function ReqHider(id){
    var testarray = document.getElementsByClassName("ReqDesc");
    for(var i = 0; i < testarray.length; i++)
    {
        testarray[i].classList.remove('Show');
        testarray[i].classList.remove('hide'); 
        testarray[i].classList.add('hide');
    }
    var testarray2 = document.getElementsByClassName("ReqHeader");
    for(var i = 0; i < testarray2.length; i++)
    {
        testarray2[i].classList.remove('Show');
        testarray2[i].classList.remove('hide');
        testarray2[i].classList.add('hide');
    }
    var testarray3 = document.getElementsByClassName("DelSel" );
    for(var i = 0; i < testarray3.length; i++)
    {
        testarray3[i].classList.remove('Show');
        testarray3[i].classList.remove('hide');
        testarray3[i].classList.add('hide');
    }
    var testarray3 = document.getElementsByClassName("DelSel" +id);
    for(var i = 0; i < testarray3.length; i++)
    {
        testarray3[i].classList.remove('Show');
        testarray3[i].classList.remove('hide');
        testarray3[i].classList.add('Show');
    }
    var testarray = document.getElementsByClassName("DelDesc");
    for(var i = 0; i < testarray.length; i++)
    {
        testarray[i].classList.remove('Show');
        testarray[i].classList.remove('hide'); 
        testarray[i].classList.add('hide');
    }
    var testarray2 = document.getElementsByClassName("DelHeader");
    for(var i = 0; i < testarray2.length; i++)
    {
        testarray2[i].classList.remove('Show');
        testarray2[i].classList.remove('hide');
        testarray2[i].classList.add('hide');
    }
   
    document.getElementById("HeaderReq" + id).classList.add('Show');
    document.getElementById("HeaderReq" + id).classList.remove('hide');
    document.getElementById("ReqDesc" + id).classList.add('Show');
    document.getElementById("ReqDesc" + id).classList.remove('hide');   

    } 

function DelHider(id){
    var testarray = document.getElementsByClassName("DelDesc");
    for(var i = 0; i < testarray.length; i++)
    {
        testarray[i].classList.remove('Show');
        testarray[i].classList.remove('hide'); 
        testarray[i].classList.add('hide');
    }
    var testarray2 = document.getElementsByClassName("DelHeader");
    for(var i = 0; i < testarray2.length; i++)
    {
        testarray2[i].classList.remove('Show');
        testarray2[i].classList.remove('hide');
        testarray2[i].classList.add('hide');
    }
    
    document.getElementById("HeaderDel" + id).classList.add('Show');
    document.getElementById("HeaderDel" + id).classList.remove('hide');
    document.getElementById("DelDesc" + id).classList.add('Show');
    document.getElementById("DelDesc" + id).classList.remove('hide');   

    }                           
</script>
 <?php
                function OpenCon()
                {
                $dbhost = "localhost";
                $dbuser = "root";
                $dbpass = "";
                $db = "MetaBeta";
                $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
                return $conn;
                }
                $conn = OpenCon();
                
?>
<div class="container hide"style="margin-bottom:300px;">
    <div class="row">
                <div class="col col-sm-4" style="border:solid black 2px;">
                    <h2>Select an Objective:</h2>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Strategic_Goals ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ObjHeader hide' id='HeaderOBJ".$row["id"]."'><h3>".$row["ObjectiveTitle"]."</h2></div>";
            
                                }
                            
                    ?>
                </div>


    </div>
    <div class="row" >
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;">
                    <div style="overflow:scroll;padding:0;min-height:250px;height:100%;">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Strategic_Goals ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ObjSel1' style='width:100%;padding:0;'><button style='text-align:left;padding:0;padding-left:10px;width:100%;' onclick=' OBJHider(".$row["id"].")'>".$row["ObjectiveTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Strategic_Goals ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ObjDesc hide' style='padding:0;' id='HeaderDesc".$row["id"]."'><h5  style='padding-left:15px;'>".$row["ObjectiveQuestion"]."</h5><textarea style='padding-left:15px;width:100%;height:290px;'>".$row["ObjectiveDescription"]."</textarea></div>";
            
                                }
                            
                    ?>
                </div>
    </div>



    <div class="row">
                <div class="col col-sm-4" style="border:solid black 2px;">
                    <h2>Select a Requirement:</h2>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ReqHeader hide' id='HeaderReq".$row["id"]."'><h3>".$row["RequirementTitle"]."</h2></div>";
            
                                }
                            
                    ?>
                </div>


    </div>
    <div class="row" >
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;">
                    <div style="overflow:scroll;padding:0;min-height:250px;height:100%;">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div id='ReqSel".$row["StrategyID"]."' class='ReqSel ReqSel".$row["StrategyID"]." hide' style='width:100%;padding:0;'><button style='text-align:left;padding:0;padding-left:10px;width:100%;' onclick=' ReqHider(".$row["id"].")'>".$row["RequirementTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Scope_Requirements ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='ReqDesc hide' style='padding:0;' id='ReqDesc".$row["id"]."'><h5  style='padding-left:15px;'>".$row["RequirementType"]."</h5><textarea style='padding-left:15px;width:100%;height:290px;'>".$row["RequirementDescription"]."</textarea></div>";
            
                                }
                            
                    ?>
                </div>


    </div>



    <div class="row">
                <div class="col col-sm-4" style="border:solid black 2px;">
                    <h2>Select a Deliverable:</h2>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='DelHeader hide' id='HeaderDel".$row["id"]."'><h3>".$row["DeliverableTitle"]."</h2></div>";
            
                                }
                            
                    ?>
                </div>


    </div>
    <div class="row" >
                <div class="col col-sm-4" style="border:solid 2px black;padding:0;min-height:150px;">
                    <div style="overflow:scroll;padding:0;min-height:250px;height:100%;">            
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div id='DelSel".$row["RequirementID"]."' class='DelSel DelSel".$row["RequirementID"]." hide' style='width:100%;padding:0;'><button style='text-align:left;padding:0;padding-left:10px;width:100%;' onclick=' DelHider(".$row["id"].")'>".$row["DeliverableTitle"]."</button></div>";
            
                                }
                            
                    ?>
                    </div>
                </div>
                <div class="col col-sm-8" style="border:solid black 2px;padding:0;">
                    <?php
                        
                            $sqlDel = "SELECT * FROM Structure_Deliverables ";
                            $Result1 = $conn->query($sqlDel);
                            while($row = $Result1->fetch_assoc()) 
                                {
                                    echo "<div class='DelDesc hide' style='padding:0;' id='DelDesc".$row["id"]."'><h5 style='padding-left:15px;'>".$row["DeliverableType"].":</h5><textarea style='padding-left:15px;width:100%;height:290px;'>".$row["DeliverableCoreIdea"]."

".$row["DeliverableDeliveryMethod"]."</textarea></div>";
            
                                }
                            
                    ?>
                </div>


    </div>
</div>
    

</body>
</html>